import React, { Component } from "react";
import { connect } from "react-redux";
import { Route, Router, Link, Redirect, Switch } from "react-router-dom";
import { Menu, Icon, Button, Input, Table, Divider, Tag, Select, Layout } from 'antd';
import createHistory from "history/createHashHistory";
/*工具类*/
import { getSize } from "../../../../utils/util";
import Slider from "react-slick";
import asyncComponent from "utils/asyncComponent"; //按需加载组件
import styles from "./index.less";
import { Scrollbars } from "components";

const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;
const Search = Input.Search;
const { Option } = Select;
var history = createHistory();
const { Header, Sider, Content } = Layout;

//表样审核
const FormReviewAll = asyncComponent({
  loader: () => import("../../../layout/personal/FormAudit/index")
  // models: () => [import("../layout/personal/formReview/model")]
});

//表样审核
const FormReviewList = asyncComponent({
  loader: () => import("../../../layout/personal/FormAudit/FormReview/index")
  // models: () => [import("../layout/personal/formReview/model")]
});


class Form extends Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 'form',
      clientHeight: getSize().windowH // 屏幕高度
    };
  }
  render() {

    const { clientHeight } = this.state;
    const { location } = this.props;
    // const menuData = getformMenu();

    return (
      <Layout style={{ height: clientHeight - 60 - 60, minHeight: '50px' }}>
        {/* 左侧菜单栏 */}

        <div style={{ height: '200px', backgroundColor: 'red' }}>
          <Menu onClick={this.handleClick} selectedKeys={[this.state.current]} mode="horizontal">
            <Menu.Item key="form">
              <Link to="form/formReview">
                <span>表样审核</span>
              </Link>

            </Menu.Item>
            <Menu.Item key="fillin">
              <Link to="form/fillinForm">
                <span>填表审核</span>
              </Link>

            </Menu.Item>
            <Menu.Item key="work">
              <Link to="">
                <span>任务审核</span>
              </Link>
            </Menu.Item>
          </Menu>
        </div>


        {/* <hr className={styles.hrN} /> */}


        <Content
          style={{
            minHeight:
              clientHeight -
              60 -
              60
          }}
        >
          <Switch
            location={location}
            key={
              location.pathname.split(
                "/"
              )[1]
            }
          >
          <Switch
            location={location}
            key={location.pathname.split("/")[1]}
          >
            {/* <AppRoute location={location} menuData={menuData} /> */}
            <Route location={location} exact path={`form/formReview`} component={<FormReviewList />} />
            <Route location={location} exact path={`form/fillinForm`} component={<fillinForm />} />
            {/* <Route path="*" render={() => <Redirect to={`form/formReview`} />} /> */}
          </Switch>
          </Switch>
        </Content>
      </Layout>
    );
  }
}

export default Form;