# 一表通前端
一表通ui

# 项目目录结构
<pre><code>
├── node_modules:                   模块文件夹
|   └── ...             
├── dist:                           打包生成目录
├── assets:                         静态文件
├── src:                            开发目录
|   ├── app:                        页面核心部分
|   |   ├── components:             页面共用组件
|   |   ├── config:                 配置文件
|   |   ├── layout:                 页面
|   |   |       ├── collection      采集管理
|   |   |       ├── form            表单大厅
|   |   |       ├── personal        个人中心
|   |   |       ├── report          报表管理
|   ├── routes:                     页面路由
|   |   ├── menu.js                 菜单文件
|   |   ├── route.js:               路由文件
|   |   ├── sidebar.js:             侧边栏文件
|   ├── models:                     dav的通用model
|   |   ├── index.js:               导出所有的通用model
|   |   ├── login.js:               登录model
|   |   ├── sys.js:                 系统model（错误处理等等）
|   ├── plugins:                    项目布局和项目共用组件
|   |   ├── container:              全局路由
|   |   ├── footer:                 页脚
|   |   ├── header:                 页头
|   |   ├── login:                  登录页面
|   |   ├── navigationBar:          面包屑
|   |   ├── noticeIcon:             头部信息按钮
|   |   ├── TabController:          页面页签
|   ├── redux:                      使用dva模式使用redux
|   |   ├── dva.js:                 dva核心代码
|   |   ├── dynamic.js:             按需加载页面model
|   ├── utils:                      工具文件包
|   |   ├── api.js:                 全局接口文件
|   |   ├── asyncComponent.js:      页面按需加载(react-loadable)
|   |   ├── AxiosUtil.js:           axios封装和拦截
|   |   ├── Loading.js:             按需加载loading(处理了model的按需加载)
|   |   ├── util.js:                工具包文件
|   └── index.js:                   入口文件
├── index.ejs                       模板文件
├── .babelrc                        babel配置文件
├── .eslintrc.json                  eslint
├── .gitignore                      git忽略文件
├── favicon.ico                     页面title小图标
├── package.json                    项目依赖 npm
├── README.MD                       项目信息
├── postcss.config.js               postcss配置文件
└── webpack.config.js               webpack配置文件
</code></pre>
