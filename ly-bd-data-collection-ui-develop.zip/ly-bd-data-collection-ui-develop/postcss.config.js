module.exports = {
  plugins: [
    require("autoprefixer")({
        ie:true,
		browsers: [ 'last 2 versions', 'Firefox ESR', '> 1%', 'not ie < 9', 'iOS >= 8', 'Android >= 4' ]
    })
  ]
};
