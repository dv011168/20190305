import { query, post, postForm } from './AxiosUtil';

let base = '/restcloud/rest/gypj';

// 登录
export const reqPostLogin = params => { return postForm(`${base}/login`, params) };
