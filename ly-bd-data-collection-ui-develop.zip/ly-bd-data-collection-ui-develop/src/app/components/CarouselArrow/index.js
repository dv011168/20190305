/*
 * @Description: 滚动-可点击箭头切换
 * @Author: qizc
 * @LastEditors: qizc
 * @Date: 2019-04-25 15:48:51
 * @LastEditTime: 2019-05-17 16:03:01
 */
import React from "react";
import { Carousel } from "antd";
import styles from "./index.less";

export default class CarouselArrow extends React.Component {
    static propTypes = {
        data: PropTypes.array,
        pageNum: PropTypes.number,
        slidesToShow: PropTypes.number,
        slidesToScroll: PropTypes.number,
        itemRender: PropTypes.func,
        onItemClick: PropTypes.func
    };

    static defaultProps = {
        data: [], // 数据
        slidesToShow: 3, // 每页显示的个数
        slidesToScroll: 3, // 滚动的个数
        onItemClick: Function.prototype // 每个子项的点击事件
    };

    // 上一页
    onPrev = () => {
        this.carouselRef && this.carouselRef.prev();
    };

    // 下一页
    onNext = () => {
        this.carouselRef && this.carouselRef.next();
    };

    render() {
        const {
            className,
            data,
            slidesToShow,
            slidesToScroll,
            itemRender,
            onItemClick,
            ...restProps
        } = this.props;

        return (
            <div className={classNames(className, styles.carouselArrow)}>
                <div className={styles.left} onClick={this.onPrev}>
                    <img src={require("images/arrow_left.png")} />
                </div>
                <div className={styles.right} onClick={this.onNext}>
                    <img src={require("images/arrow_right.png")} />
                </div>
                <Carousel
                    ref={node => {
                        this.carouselRef = node;
                    }}
                    dots={false}
                    slidesToShow={slidesToShow}
                    slidesToScroll={slidesToScroll}
                    {...restProps}
                >
                    {data.map((item, i) => {
                        return (
                            <div key={i} className="carouselArrow-item">
                                {itemRender ? (
                                    itemRender(item, i)
                                ) : (
                                    <div
                                        className="carouselArrow-itemCon"
                                        onClick={() => onItemClick(item)}
                                    >
                                        <img src={item.img} />
                                        <div className="carouselArrow-itemTitle">
                                            {item.name}
                                        </div>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </Carousel>
            </div>
        );
    }
}
