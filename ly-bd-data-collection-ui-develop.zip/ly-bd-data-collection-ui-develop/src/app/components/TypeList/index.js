/*
 * @Description: 头部类型列表
 * @Author: qizc
 * @LastEditors: qizc
 * @Date: 2019-04-25 15:48:51
 * @LastEditTime: 2019-04-29 14:08:43
 */
import React from "react";
import classNames from "classnames";
import styles from "./index.less";

export default class TypeList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        const { className, data = [] } = this.props;
        // 每个子项的宽度
        const width = 100 / data.length;

        return (
            <div className={classNames(className, styles.typeBox)}>
                <div className="w1180">
                    {data.map((item, index) => {
                        return (
                            <div
                                key={index}
                                span={6}
                                className="typeItem"
                                style={{ width: `${width}%` }}
                            >
                                <div className="typeTitle">{item.title}</div>
                                <div>{item.info}</div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    }
}
