import React from "react";
import classNames from "classnames";
import styles from './index.less'

const Title = props => {
    const { className, text } = props;
    return (
        <div className={classNames(className, styles.titleBox)}>
            <div className="inner-title">{text}</div>
        </div>
    );
};

export default Title;
