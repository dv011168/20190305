/*
 * @Description: LyAnchor 锚点
 * @Author: qizc
 * @Date: 2018-10-29 14:33:56
 * @LastEditors: qizc
 * @LastEditTime: 2019-01-21 17:01:12
 */
import React from "react";
import { Anchor } from "antd";

const { Link } = Anchor;

export default class LyAnchor extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const { data = [], location, ...other } = this.props;

        const getLink = item => {
            if (item.children && item.children != "" && item.show) {
                const childLink = item.children.map((itemM, i) => {
                    return getLink(itemM);
                });
                return (
                    <Link
                        key={item.key}
                        href={`#${location.pathname}#tree-${item.key}`}
                        title={item.title}
                    >
                        {childLink}
                    </Link>
                );
            } else {
                return (
                    <Link
                        key={item.key}
                        href={`#${location.pathname}#tree-${item.key}`}
                        title={item.title}
                    />
                );
            }
        };
        return (
            <div className="ly-anchor">
                <Anchor {...other}>
                    {data.map((item, index) => getLink(item))}
                </Anchor>
            </div>
        );
    }
}
