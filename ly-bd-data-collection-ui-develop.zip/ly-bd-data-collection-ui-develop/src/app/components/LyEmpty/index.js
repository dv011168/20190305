/*
 * @Description: LyCard 卡片
 * @Author: qizc
 * @Date: 2018-10-29 14:33:56
 * @LastEditors: qizc
 * @LastEditTime: 2019-03-01 17:58:11
 */
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import "./index.less";

export default class LyEmpty extends React.Component {
    static propTypes = {
        text: PropTypes.string
    };

    static defaultProps = {
        text: "暂无数据", // 提示文字
    };

    render() {
        const { className, text } = this.props;

        return (
            <div className={classNames("ly-empty", className)}>
                {text}
            </div>
        );
    }
}
