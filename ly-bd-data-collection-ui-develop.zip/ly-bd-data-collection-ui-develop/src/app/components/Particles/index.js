/*
 * @Description: 粒子
 * @Author: qizc
 * @LastEditors: qizc
 * @Date: 2019-04-25 15:48:51
 * @LastEditTime: 2019-05-09 16:11:44
 */
import React from "react";
import { createScript } from "utils/util";

export default class Particles extends React.Component {
    static propTypes = {
        id: PropTypes.string
    };

    static defaultProps = {
        id: "particles-js"
    };

    componentDidMount() {
        const { id } = this.props;
        createScript("./assets/js/particles/particles.min.js").then(() => {
            particlesJS.load(
                id,
                "./assets/js/particles/config.json",
                function() {
                    console.log("callback - particles-js config loaded");
                }
            );
        });
    }

    render() {
        const { className, id } = this.props;

        return <div id={id} className={className} />;
    }
}
