/*
 * @Description: LyMore 更多
 * @Author: qizc
 * @Date: 2018-10-29 14:33:56
 * @LastEditors: qizc
 * @LastEditTime: 2019-05-17 16:17:55
 */
import React from "react";
import { Icon } from "antd";
import { Link } from "react-router-dom";
import classNames from "classnames";
import "./index.less";

export default class LyMore extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const { className, to = '', text = "查看更多", icon, hideIcon, onMore, ...other } = this.props;
		let _icon = icon || <Icon type="double-right" />;
		
		// 手动跳转
		const onClick = (e) => {
			if(onMore && !to){
				e.preventDefault()
				onMore()
			}
		}
        return (
            <Link to={to} onClick={onClick} className={classNames("ly-more", className)} {...other}>
                <span>{text}</span>
                {hideIcon ? null : <span className="ly-more-icon">{_icon}</span>}
            </Link>
        );
    }
}
