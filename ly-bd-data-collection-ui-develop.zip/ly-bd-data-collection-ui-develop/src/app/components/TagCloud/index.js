/*
 * @Description: 标签云
 * @Author: qizc
 * @LastEditors: qizc
 * @Date: 2019-04-25 15:48:51
 * @LastEditTime: 2019-05-09 16:11:28
 */
import React from "react";
import { createScript } from "utils/util";

// 随机数
const random = (b, a) => {
    return Math.floor(b + Math.random() * (a - b));
}

export default class Tagcloud extends React.Component {
	static propTypes = {
		config: PropTypes.obj,
		colors: PropTypes.array,
		data: PropTypes.array,
    };

    static defaultProps = {
        config: {
			//参数名: 默认值
			fontsize: 16, //基本字体大小
			radius: 75, //滚动半径
			mspeed: "slow", //滚动最大速度
			ispeed: "slow", //滚动初速度
			direction: 135, //初始滚动方向
			keep: true //鼠标移出组件后是否继续随鼠标滚动
		},
		data: [],
		colors: ["rgb(232,72,85)", "rgb(28,119,195)", "rgb(249,220,92)","rgba(33,163,230,1)","rgba(39,191,158,1)"]
	};

    componentDidMount() {
		const { config } = this.props;
        createScript("./assets/js/tagcloud/tagcloud.min.js").then(() => {
            tagcloud(config);
        });
    }

    render() {
        const { className, data, colors } = this.props;
		
        return (
            <div className={className} style={{ height: 200, width: 320 }}>
                <div className="tagcloud">
                    {data.map(item => {
                        // 随机颜色
                        const colorIndex = random(0, colors.length);

                        return (
                            <a  style={{ color: colors[colorIndex] }}>
                                {item.label}
                            </a>
                        );
                    })}
                </div>
            </div>
        );
    }
}
