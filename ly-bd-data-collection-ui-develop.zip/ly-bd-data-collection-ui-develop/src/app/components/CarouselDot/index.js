/*
 * @Description: 滚动-可点击切换
 * @Author: qizc
 * @LastEditors: qizc
 * @Date: 2019-04-25 15:48:51
 * @LastEditTime: 2019-05-17 16:03:13
 */
import React from "react";
import { Carousel } from "antd";
import { cutArray } from "utils/util";
import styles from "./index.less";

export default class CarouselDot extends React.Component {
    static propTypes = {
        data: PropTypes.array,
        pageNum: PropTypes.number,
        lineNum: PropTypes.number,
        itemRender: PropTypes.func,
        onItemClick: PropTypes.func
    };

    static defaultProps = {
        data: [], // 数据
        pageNum: 6, // 每页的条数
        lineNum: 2, // 每一行的条数
        onItemClick: Function.prototype // 每个子项的点击事件
    };

    render() {
        const {
            className,
            data,
            pageNum,
            lineNum,
            itemRender,
            onItemClick,
            ...restProps
        } = this.props;
        // 切割数据成多页
        const list = cutArray(data, pageNum);
        // 每个子项的宽度
        const width = 100 / lineNum;

        return (
            <Carousel
                className={classNames(className, styles.carouselDot)}
                {...restProps}
            >
                {list.map((item, i) => {
                    return (
                        <div key={i}>
                            {item.map((itM, j) => {
                                if (itemRender) {
                                    return itemRender(itM, j, i);
                                }
                                return (
                                    <div
                                        className="carouselDot-item"
                                        style={{ width: `${width}%` }}
                                    >
                                        <div
                                            className="carouselDot-itemCon"
                                            onClick={() => onItemClick(itM)}
                                        >
                                            <div className="carouselDot-itemImg">
                                                <img src={itM.img} />
                                            </div>
                                            <div className="carouselDot-itemTitle">
                                                {itM.name}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    );
                })}
            </Carousel>
        );
    }
}
