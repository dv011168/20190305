import React from "react";
import classNames from "classnames";
import styles from "./index.less";

const data = [
    {
        label: "未启动",
        value: 0
    },
    {
        label: "进行中",
        value: 1
    },
    {
        label: "终止",
        value: 2
    },
    {
        label: "已结束",
        value: 3
    },
    {
        //橙色
        label: "待填写",
        value: 11
    },
    {
        //蓝色
        label: "进行中",
        value: 12
    },
    {
        //红色
        label: "已过期",
        value: 13
    },
    {
        //灰色
        label: "已退回",
        value: 14
    },
    {
        //红色
        label: "不通过",
        value: 15
    },
    {
        //绿色
        label: "通过",
        value: 16
    },
    {
        //灰色
        label: "中断",
        value: 17
    }
];

const TagStatus = props => {
    const { className, status = 0 } = props;
    // 获取匹配的信息
	const statusInfo = data.filter(v => v.value == status) || [{}];
    return (
        <div
            className={classNames(className, styles.tag, {
                [styles.tag_1]: [12].includes(statusInfo[0].value) ,
                [styles.tag_2]: [14,17].includes(statusInfo[0].value),
                [styles.tag_3]: [16].includes(statusInfo[0].value),
                [styles.tag_4]: [13,15].includes(statusInfo[0].value),
            })}
        >
            {statusInfo[0] && statusInfo[0].label}
        </div>
    );
};

export default TagStatus;
