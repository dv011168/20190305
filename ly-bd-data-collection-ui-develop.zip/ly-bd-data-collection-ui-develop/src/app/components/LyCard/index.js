/*
 * @Description: LyCard 卡片
 * @Author: qizc
 * @Date: 2018-10-29 14:33:56
 * @LastEditors: qizc
 * @LastEditTime: 2019-05-17 16:53:33
 */
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Card } from "antd";
import { Scrollbars } from "components";
import "./index.less";

export default class LyCard extends React.Component {
    static propTypes = {
        height: PropTypes.number,
        bordered: PropTypes.bool,
        isScroll: PropTypes.bool
    };

    static defaultProps = {
        height: 316, // 卡片高度
        bordered: false, // 是否有边框
        isScroll: true // 是否有滚动条
    };

    constructor(props) {
        super(props);
    }

    render() {
        const {
            className,
            title,
            height,
            bordered,
            isScroll,
            children,
            ...other
        } = this.props;

        const innerHeight = title ? height - 48 : height;
        const cardInner = isScroll ? (
            <Scrollbars style={{ height: innerHeight, width: "100%" }}>
                <div className="ly-card-inner">{children}</div>
            </Scrollbars>
        ) : (
            <div
                className="ly-card-inner"
                style={{ height: innerHeight, width: "100%" }}
            >
                {children}
            </div>
        );

        return (
            <div
                className={classNames("ly-card", className)}
                style={{ height: height }}
            >
                <Card title={title} {...other} bordered={bordered}>
                    {cardInner}
                </Card>
            </div>
        );
    }
}
