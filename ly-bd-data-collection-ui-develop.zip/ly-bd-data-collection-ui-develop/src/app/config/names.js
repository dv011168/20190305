
export const AUTH = {
    LOGIN: "/auth/login",
    LOGOUT: "/auth/logout"
}
