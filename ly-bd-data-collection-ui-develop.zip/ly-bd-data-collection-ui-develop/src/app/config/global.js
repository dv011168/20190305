export const config = {
    appId : "license",
    title: "数据治理工程信息服务门户",
    english: "",
	copyright: "版权所有 © 联奕科技有限公司 Copyright © 2019.All rights reserved.",
}