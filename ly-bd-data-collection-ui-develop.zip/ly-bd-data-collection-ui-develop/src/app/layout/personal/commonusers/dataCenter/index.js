/*
 * @Description: 用户信息
 * @Author: qizc
 * @LastEditors: qizc
 * @Date: 2019-04-25 15:48:51
 * @LastEditTime: 2019-05-17 17:48:24
 */
import React from "react";
import { LyCard, TagCloud } from "components";
import styles from "./index.less";

export default class DataCenter extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        const { tagList = [] } = this.props;
        return (
            <LyCard
                isScroll={false}
                title="个人数据中心"
                className={styles.box}
                height={285}
            >
                <TagCloud data={tagList} className={styles.tags} />
            </LyCard>
        );
    }
}
