// 常用填写
export const cytxData = [
    {
        name: "工作周报表",
        img: require("images/personal/cytx/gzzbb.png"),
    },
    {
        name: "职员申请表",
        img: require("images/personal/cytx/zysqb.png"),
    },
    {
        name: "初次认定职务申请表",
        img: require("images/personal/cytx/zysqb.png"),
    },
    {
        name: "秋冬校服采购申请表",
        img: require("images/personal/cytx/gzzbb.png"),
    },
    {
        name: "班级信息申请表",
        img: require("images/personal/cytx/zysqb.png"),
    
    },
    {
        name: "差旅报备表",
        img: require("images/personal/cytx/clbbb.png"),
    
    }
];

// 标签云数据
export const tagList = [
    { label: "B型" },
    { label: "工程师" },
    { label: "农村户口" },
    { label: "8368695" },
    { label: "共产党员" },
    { label: "专任教师" },
    { label: "Name D-Wade" },
    { label: "秦韦德" },
    { label: "1994年11月6日" },
    { label: "工学学位" },
    { label: "人事处" },
    { label: "博士研究生" },
    { label: "20190313" },
    { label: "计算机学院" },
    { label: "工龄4年" },
    { label: "广州市天河区棠东村" },
    { label: "在编人员" },

];