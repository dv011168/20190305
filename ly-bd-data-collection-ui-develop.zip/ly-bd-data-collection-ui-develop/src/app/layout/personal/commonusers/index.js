import React from "react";
import styles from "./index.less";
import { Table, Modal, Button, Input, Row, Col } from "antd";
import { Link } from "react-router-dom";
import { cytxData, tagList } from "./data.js";
import { TagCloud } from "components";
import UserInfo from "./userInfo"; // 用户信息
import DataCenter from "./dataCenter"; // 数据中心
import Info from "./info"; // 填写信息

const { TextArea } = Input;
class Commonusers extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showModal: false
        };
    }
    columns = [
        {
            title: "表名",
            dataIndex: "name",
            key: "name",
            render: text => <a href="javascript:;">{text}</a>
        },
        {
            title: "所属采集任务",
            dataIndex: "sscjrw",
            key: "sscjrw"
        },
        {
            title: "时间",
            dataIndex: "sj",
            key: "sj"
        },
        {
            title: "状态",
            key: "zt",
            dataIndex: "zt",
            render: (text, record) => {
                if (text === "已过期") {
                    return <div className={styles.zt_ygq}>已过期</div>;
                } else if (text === "待填写") {
                    return <div className={styles.zt_dtx}>待填写</div>;
                } else if (text === "通过") {
                    return <div className={styles.zt_tg}>通过</div>;
                } else if (text === "已退回") {
                    return <div className={styles.zt_yth}>已退回</div>;
                } else if (text === "进行中") {
                    return <div className={styles.zt_jxz}>进行中</div>;
                }
                // else if(text ==='中断'){
                //   return <div className={styles.status_interrupt}>中断</div>
                // }
            }
        },
        {
            title: "操作",
            key: "action",
            render: (text, record) => {
                if (record.zt === "已过期") {
                    return (
                        <div>
                            <div
                                className={styles.cz_sqbt}
                                onClick={this.showModal}
                            >
                                申请补填
                            </div>
                            <div className={styles.cz_DivR2}>忽略</div>
                        </div>
                    );
                } else if (record.zt === "待填写") {
                    return (
                        <div>
                            <div className={styles.cz}>填写</div>
                            <div className={styles.cz_DivR}>查看</div>
                        </div>
                    );
                } else if (record.zt === "通过") {
                    return (
                        <div>
                            <div className={styles.cz}>忽略</div>
                            <div className={styles.cz_DivR}>查看</div>
                        </div>
                    );
                } else if (record.zt === "已退回") {
                    return (
                        <div>
                            <div className={styles.cz}>填写</div>
                            <div className={styles.cz_DivR}>查看</div>
                        </div>
                    );
                } else if (record.zt === "进行中") {
                    return (
                        <div>
                            <div className={styles.cz}>撤回</div>
                            <div className={styles.cz_DivR}>查看</div>
                        </div>
                    );
                }
            }
        }
    ];
    data = [
        {
            key: "1",
            name: "学生会组织申请表",
            sscjrw: "个人资料采集",
            sj: "2019.3.12日提交",
            zt: "已过期"
        },
        {
            key: "2",
            name: "职员申请表",
            sscjrw: "个人资料采集",
            sj: "2019.3.12日提交",
            zt: "待填写"
        },
        {
            key: "3",
            name: "初次认定职务申报表",
            sscjrw: "个人资料采集",
            sj: "2019.3.12日提交",
            zt: "已退回"
        },
        {
            key: "4",
            name: "共青团员登记表",
            sscjrw: "个人资料采集",
            sj: "2019.3.12日提交",
            zt: "进行中"
        },
        {
            key: "5",
            name: "贫困生登记",
            sscjrw: "个人资料采集",
            sj: "2019.3.12日提交",
            zt: "进行中"
        },
        {
            key: "6",
            name: "奖学金申请",
            sscjrw: "个人资料采集",
            sj: "2019.3.12日提交",
            zt: "进行中"
        },
        {
            key: "7",
            name: "教务室活动申请",
            sscjrw: "个人资料采集",
            sj: "2019.3.12日提交",
            zt: "进行中"
        },
        {
            key: "8",
            name: "公共空间使用申请",
            sscjrw: "个人资料采集",
            sj: "2019.3.12日提交",
            zt: "通过"
        }
    ];
    handleOk = () => {
        this.setState({
            showModal: false
        });
    };
    showModal = () => {
        this.setState({
            showModal: true
        });
    };
    render() {
        return (
            <div className="p20">
                <Row gutter={20}>
                    <Col span={5}>
                        <UserInfo />
                        <DataCenter tagList={tagList} />
                    </Col>
                    <Col span={14}>
						<Info />
					</Col>
                    <Col span={5}>1</Col>
                </Row>
            </div>
        );
        return (
            <div className={styles.box}>
                <div className={styles.leftDiv}>
                    <div className={styles.dataTopic}>
                        <div className={styles.itemPersonU}>数据主题</div>
                        <div className={styles.itemPersonD}>
                            <div className={styles.itemUp}>
                                <div className={styles.itemUpLeft}>
                                    <img
                                        className={styles.imgL}
                                        src={require("images/personal/datatopic/grxx.png")}
                                    />
                                    <div className={styles.personaltext2}>
                                        个人信息
                                    </div>
                                </div>
                                <div className={styles.itemUpMiddle}>
                                    <img
                                        className={styles.imgM}
                                        src={require("images/personal/datatopic/cwxx.png")}
                                    />
                                    <div className={styles.personaltext2}>
                                        财务信息
                                    </div>
                                </div>
                                <div className={styles.itemUpRight}>
                                    <img
                                        className={styles.imgR}
                                        src={require("images/personal/datatopic/kyxx.png")}
                                    />
                                    <div className={styles.personaltext2}>
                                        科研信息
                                    </div>
                                </div>
                            </div>
                            <div className={styles.itemDown}>
                                <div className={styles.itemDownLeft}>
                                    <img
                                        className={styles.imgL}
                                        src={require("images/personal/datatopic/zcxx.png")}
                                    />
                                    <div className={styles.personaltext2}>
                                        资产信息
                                    </div>
                                </div>
                                <div className={styles.itemDownMiddle}>
                                    <img
                                        className={styles.imgM}
                                        src={require("images/personal/datatopic/jxxx.png")}
                                    />
                                    <div className={styles.personaltext2}>
                                        教学信息
                                    </div>
                                </div>
                                <div className={styles.itemDownRight}>
                                    <img
                                        className={styles.imgR}
                                        src={require("images/personal/datatopic/shxx.png")}
                                    />
                                    <div className={styles.personaltext2}>
                                        生活信息
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className={styles.middleDiv}>
                    <div className={styles.itemTb}>
                        <div className={styles.itemDtx}>
                            <div className={styles.itemD}>
                                <div>
                                    <img
                                        className={styles.imgR}
                                        src={require("images/personal/dblsx/dtx.png")}
                                    />
                                    <div className={styles.itemTextA}>
                                        <div className={styles.itemTextB}>
                                            待填写
                                        </div>
                                        <div className={styles.itemTextC}>
                                            当前待填写总数
                                        </div>
                                    </div>

                                    <div className={styles.itemTextRs}>14</div>
                                </div>
                            </div>
                        </div>
                        <div className={styles.itemJxz}>
                            <div className={styles.itemD}>
                                <img
                                    className={styles.imgR}
                                    src={require("images/personal/dblsx/jxz.png")}
                                />
                                <div className={styles.itemTextA}>
                                    <div className={styles.itemTextB}>
                                        进行中
                                    </div>
                                    <div className={styles.itemTextC}>
                                        当前进行中总数
                                    </div>
                                </div>
                                <div className={styles.itemTextRs}>23</div>
                            </div>
                        </div>
                        <div className={styles.itemYwc}>
                            <div className={styles.itemD}>
                                <img
                                    className={styles.imgR}
                                    src={require("images/personal/dblsx/ywc.png")}
                                />
                                <div className={styles.itemTextA}>
                                    <div className={styles.itemTextB}>
                                        已完成
                                    </div>
                                    <div className={styles.itemTextC}>
                                        当前已完成总数
                                    </div>
                                </div>
                                <div className={styles.itemTextRs}>53</div>
                            </div>
                        </div>
                    </div>
                    <div className={styles.itemBgDiv}>
                        <div className={styles.itemWdtbU}>
                            <div className={styles.wdtbText}>我的填表</div>
                            <div className={styles.ckgd}>
                                <Link to="/personal/commonUsers/myForm">
                                    查看更多>>
                                </Link>
                            </div>
                        </div>
                        <div className={styles.itemWdtbM}>
                            <div className={styles.tx}>
                                {" "}
                                <img
                                    className={styles.txImg}
                                    src={require("images/personal/dblsx/tx.png")}
                                />
                                <div className={styles.nyText}>您有</div>
                                <div className={styles.gqbts}>2</div>
                                张已过期表单需要处理
                            </div>
                        </div>
                        <div className={styles.itemWdtbD}>
                            <Table
                                columns={this.columns}
                                dataSource={this.data}
                                pagination={false}
                                size={"middle"}
                                onHeaderRow={() => {}}
                            />
                        </div>
                    </div>
                    <div className={styles.itemWdbbDiv}>
                        <div className={styles.itemWdtbU}>
                            <div className={styles.wdtbText}>我的报表</div>
                            <div className={styles.ckgd}>查看更多>></div>
                        </div>
                        <div className={styles.itemWdtbD}>
                            <img
                                className={styles.wdbbImgL}
                                src={require("images/personal/wdbb/arrow_left.png")}
                            />
                            <div className={styles.bbx}>
                                <div className={styles.bbxDiv}>
                                    <img
                                        src={require("images/personal/wdbb/zbb.png")}
                                    />
                                </div>
                                <div className={styles.personaltext2}>
                                    工作周报表
                                </div>
                            </div>

                            <div className={styles.bbx}>
                                <div className={styles.bbxDiv}>
                                    <img
                                        src={require("images/personal/wdbb/zbb.png")}
                                    />
                                </div>
                                <div className={styles.personaltext2}>
                                    工作月报表
                                </div>
                            </div>

                            <div className={styles.bbx}>
                                <div className={styles.bbxDiv}>
                                    <img
                                        src={require("images/personal/wdbb/zbb.png")}
                                    />
                                </div>
                                <div className={styles.personaltext2}>
                                    工作年报表
                                </div>
                            </div>

                            <div className={styles.bbx}>
                                <div className={styles.bbxDiv}>
                                    <img
                                        src={require("images/personal/wdbb/rdb.png")}
                                    />
                                </div>
                                <div className={styles.personaltext2}>
                                    初次认定职务申请表
                                </div>
                            </div>

                            <div className={styles.bbx}>
                                <div className={styles.bbxDiv}>
                                    <img
                                        src={require("images/personal/wdbb/jssqb.png")}
                                    />
                                </div>
                                <div className={styles.personaltext2}>
                                    公共教室申请表
                                </div>
                            </div>

                            <div className={styles.bbx}>
                                <div className={styles.bbxDiv}>
                                    <img
                                        src={require("images/personal/wdbb/jssqb.png")}
                                    />
                                </div>
                                <div className={styles.personaltext2}>
                                    公共教室申请表
                                </div>
                            </div>

                            <img
                                className={styles.wdbbImgR}
                                src={require("images/personal/wdbb/arrow_right.png")}
                            />
                        </div>
                    </div>
                </div>
                <div className={styles.rightDiv}>
                    <div className={styles.itemCytx}>
                        <div className={styles.itemCytxU}>常用填写</div>
                        <div className={styles.itemCytxD}>
                            {cytxData.map((item, index) => {
                                const card = (
                                    <div className={styles.reportCard}>
                                        <div className={styles.card}>
                                            <div>
                                                <div
                                                    className={styles.imgCircle}
                                                >
                                                    <img
                                                        className={
                                                            styles.imgStyle
                                                        }
                                                        src={item.img}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className={styles.textBox}>
                                            <div className={styles.cytxtext}>
                                                {item.name}
                                            </div>
                                        </div>
                                    </div>
                                );
                                return card;
                            })}
                            <div className={styles.dot}>
                                <div className={styles.dotL} />
                                <div className={styles.dotM} />
                                <div className={styles.dotR} />
                            </div>
                        </div>
                    </div>
                    <div className={styles.itemWdsc}>
                        <div className={styles.itemWdscU}>我的收藏</div>
                        <div className={styles.itemWdscD}>
                            {cytxData.map((item, index) => {
                                const card = (
                                    <div className={styles.reportCard}>
                                        <div className={styles.card}>
                                            <div>
                                                <div
                                                    className={styles.imgCircle}
                                                >
                                                    <img
                                                        className={
                                                            styles.imgStyle
                                                        }
                                                        src={item.img}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        <div className={styles.textBox}>
                                            <div className={styles.cytxtext}>
                                                {item.name}
                                            </div>
                                        </div>
                                    </div>
                                );
                                return card;
                            })}
                            <div className={styles.dot}>
                                <div className={styles.dotL} />
                                <div className={styles.dotM} />
                                <div className={styles.dotR} />
                            </div>
                        </div>
                    </div>
                </div>
                <Modal
                    visible={this.state.showModal}
                    maskClosable={false}
                    width={600}
                    onCancel={() => {
                        this.setState({
                            showModal: false
                        });
                    }}
                    onOk={() => {
                        this.setState({
                            showModal: false
                        });
                    }}
                    title={"申请补填"}
                    footer={
                        <div style={{ marginRight: 35 }}>
                            <Button
                                style={{ marginRight: 10 }}
                                key="back"
                                onClick={() => {
                                    this.setState({
                                        showModal: false
                                    });
                                }}
                            >
                                取消
                            </Button>
                            <Button
                                key="submit"
                                type="primary"
                                onClick={this.handleOk}
                            >
                                提交申请
                            </Button>
                        </div>
                    }
                >
                    <div>
                        <div style={{ height: 350 }}>
                            <div className={styles.title}>任务名：</div>
                            <div className={styles.modalText}>周报任务采集</div>
                            <div className={styles.title}>表名：</div>
                            <div className={styles.modalText}>工作周报表</div>
                            <div className={styles.title}>申请人：</div>
                            <div className={styles.modalText}>刘志宝</div>
                            <div className={styles.title}>申请时间：</div>
                            <div className={styles.modalText}>
                                2019-03-22 15:43
                            </div>
                            <div className={styles.title}>申请原因：</div>
                            <TextArea
                                placeholder="请填写申请原因"
                                // autosize={{ minRows: 8, maxRows: 8 }}
                                rows={8}
                                style={{
                                    width: 400,
                                    height: 200,
                                    verticalAlign: "top"
                                }}
                            />
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
}

export default Commonusers;
