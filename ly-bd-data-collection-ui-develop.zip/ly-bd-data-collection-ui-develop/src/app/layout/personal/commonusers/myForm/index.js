import React, { Component } from 'react';
import styles from "./index.less";
import { Menu, Icon, Button, Input, Table, Modal, Tag, Select } from 'antd';
import TagStatus from '../../../../components/TagStatus/index';

const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;
const Search = Input.Search;

const {TextArea} = Input;
const { Option } = Select;

class MyForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 'form',
      showModal:false,
    };
  }


  handleClick = e => {
    console.log('click ', e);
    this.setState({
      current: e.key,
    });
  };


  //创建时间
  getSortData = (value, record) => {

    // console.log(value,record);
    console.log(value);
    let count = 0;
    if (record.stuname.indexOf(value) != -1) {
      // count++;
      return record;
    }
  }


  //筛选状态
  getSortStatus = (value, record) => {
    if (value === 'all') {
      return record
    } else {
      if (record.status.indexOf(value) != -1) {
        // count++;
        return record;
      }
    }
  }

  //根据状态修改颜色
  getStatus = (value, record) => {
    // console.log(value);
    // console.log(record);
    if (value === '未完成') {
      return `<span style={{color:'red'}}>测试</span>`
    } else if (value === '已完成') {
      return `<span style={{color:'green'}}>测试</span>`
    }
  }
  showModal = () => {
    this.setState({
        showModal: true
    })
}
  render() {
    const columns = [
      {
        title: '表名',
        dataIndex: 'formName',
        key: 'formName',
        //   render: text => <a href="javascript:;">{text}</a>,
      },
      {
        title: '所属采集任务',
        dataIndex: 'sscjrw',
        key: 'sscjrw',
      },
      {
        title: '时间',
        dataIndex: 'createTime',
        key: 'createTime',
        filters: [
          {
            text: '三个月',
            value: 'threeM',
          },
          {
            text: '半年',
            value: 'sixM',
          },
          {
            text: '自定义',
            value: 'Submenu',
            children: [
              {
                text: '1年',
                value: 'oneY',
              },
              {
                text: '2年',
                value: 'twoY',
              },
            ],
          },
        ],
        // specify the condition of filtering result
        // here is that finding the name started with `value`
        onFilter: (value, record) => { return this.getSortData(value, record) },
        // sorter: (a, b) => a.name.length - b.name.length,
        // sortDirections: ['descend'],
        filterIcon: () => {
          return <Icon type="caret-down" />
        },
        filterMultiple: false,
      },
      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: (text, record) => {
          return <TagStatus status={record.status}/>
        },
      },
      {
        title: '操作',
        key: 'action',
        render: (text, record) => {
          if (record.status === 13) {
              return <div><div className={styles.cz_sqbt} onClick={this.showModal}>申请补填</div><div className={styles.cz_DivR2}>忽略</div></div>
          }
          else if (record.status === 11) {
              return <div><div className={styles.cz}>填写</div><div className={styles.cz_DivR}>查看</div></div>
          } else if (record.status === 16) {
              return <div><div className={styles.cz}>忽略</div><div className={styles.cz_DivR}>查看</div></div>
          } else if (record.status === 14) {
              return <div><div className={styles.cz}>填写</div><div className={styles.cz_DivR}>查看</div></div>
          } else if (record.status === 12) {
              return <div><div className={styles.cz}>撤回</div><div className={styles.cz_DivR}>查看</div></div>
          }else if(record.status===15){
              return <div><div className={styles.cz}>忽略</div><div className={styles.cz_DivR}>查看</div></div>
          }else if(record.status===17){
              return <div><div className={styles.cz}>忽略</div><div className={styles.cz_DivR}>查看</div></div>
          }
      },
      }
    ];



    const data = [
      {
        key: '1',
        formName: '学生会组织申请表',
        sscjrw: '个人资料采集',
        createTime: '已过期3天',
        status: 13
      },
      {
        key: '2',
        formName: '班级信息收集表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 11
      },
      {
        key: '3',
        formName: '校园车辆登记表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 13
      },
      {
        key: '4',
        formName: '贫困生补助表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 12
      },
      {
        key: '5',
        formName: '学工处人员登记表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 12
      },
      {
        key: '6',
        formName: '留学生宿舍申报表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 12
      },
      {
        key: '7',
        formName: '差旅费报备表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 12
      },
      {
        key: '8',
        formName: '实验室设备登记表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 14
      },
      {
        key: '9',
        formName: '互联网+大赛报名表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 15
      },
      {
        key: '10',
        formName: '差旅费报备表',
        sscjrw: '个人资料采集',
        createTime: '2019-03-12',
        status: 17
      },

    ];

    const rowSelection = {};
    return (
      <div className={styles.review_box}>

        <div className={styles.title}> 当前位置：个人中心 > 我的填表</div>
        <div className={styles.b_button}>
          <div className={styles._div_f}>全部</div>
          <div className={styles._div_m}>待填写</div>
          <div className={styles._div_m}>进行中</div>
          <div className={styles._div_z}>已结束</div>
          <div style={{ float: 'right', minWidth: '388px', height: '36px', marginRight: '20px' }}>
            <Search
              placeholder="请输入表名"
              enterButton="搜索"
              // size="large"
              onSearch={value => console.log(value)}
            />
          </div>
        </div>

        <div className={styles.tableTip}>
          <Icon type="info-circle" />
          <span>全部：11 项  待填写：4 项  进行中：4 项  已过期：1 项</span>
        </div>

        <div className={styles.tableData}>
          <Table columns={columns} dataSource={data} bordered={true}
            pagination={{
              // position:"both"
              showSizeChanger: true,
              showQuickJumper: true,
              total: 500,
              showTotal: () => { return `共50页` },    //显示多少条记录(total) => {return this.showTotald(total)},
            }} />
        </div>
        <Modal visible={this.state.showModal} maskClosable={false}
                    width={600}
                    onCancel={() => {
                        this.setState({
                            showModal:false
                        })
                    }}
                    onOk={()=>{
                        this.setState({
                            showModal:false
                        })
                    }}
                    title={'申请补填'}
                    footer={
                        <div style={{ marginRight: 35 }}>
                            

                            <Button style={{ marginRight: 10 }} key="back" onClick={() => {
                                this.setState({
                                    showModal:false
                                })
                            }}>取消</Button>
                            <Button  key="submit" type="primary" onClick={this.handleOk} >提交申请</Button>
                        </div>
                    }
                >
                    <div >
                        <div style={{height:350}}>
                            <div className={styles.title2}>任务名：</div><div className={styles.modalText}>周报任务采集</div>
                            <div className={styles.title2}>表名：</div><div className={styles.modalText}>工作周报表</div>
                            <div className={styles.title2}>申请人：</div><div className={styles.modalText}>刘志宝</div>
                            <div className={styles.title2}>申请时间：</div>
                            <div className={styles.modalText}>2019-03-22 15:43</div>
                            <div className={styles.title2}>申请原因：</div><TextArea
                                placeholder="请填写申请原因"
                                // autosize={{ minRows: 8, maxRows: 8 }}
                                rows={8}
                                style={{ width: 400, height: 200, verticalAlign: 'top'}}
                            />

                        </div>
                    </div>
                </Modal>
      </div>

    );
  }
}

export default MyForm;