/*
 * @Description: 信息
 * @Author: qizc
 * @LastEditors: qizc
 * @Date: 2019-04-25 15:48:51
 * @LastEditTime: 2019-05-17 17:54:02
 */
import React from "react";
import { Row, Col } from "antd";
import { LyCard } from "components";
import styles from "./index.less";

export default class Info extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <Row gutter={20} className={styles.box}>
                <Col span={8}>
                    <LyCard height={140} isScroll={false}>
                        <div className={styles.cardBox}>
                            <div className={styles.cardImg}>
                                <img
                                    src={require("images/personal/dblsx/dtx.png")}
                                />
                            </div>
                            <div className={styles.cardBoxCon}>
                                <div className={styles.cardTitle}>待填写</div>
                                <div>当前待填写总数</div>
                            </div>
                            <div className={styles.cardBoxNum}>14</div>
                        </div>
                    </LyCard>
                </Col>
                <Col span={8}>
                    <LyCard height={140} isScroll={false}>
                        <div className={styles.cardBox}>
                            <div className={styles.cardImg}>
                                <img
                                    src={require("images/personal/dblsx/jxz.png")}
                                />
                            </div>
                            <div className={styles.cardBoxCon}>
                                <div className={styles.cardTitle}>进行中</div>
                                <div>当前进行中总数</div>
                            </div>
                            <div className={styles.cardBoxNum}>23</div>
                        </div>
                    </LyCard>
                </Col>
                <Col span={8}>
                    <LyCard height={140} isScroll={false}>
                        <div className={styles.cardBox}>
                            <div className={styles.cardImg}>
                                <img
                                     src={require("images/personal/dblsx/ywc.png")}
                                />
                            </div>
                            <div className={styles.cardBoxCon}>
                                <div className={styles.cardTitle}>已完成</div>
                                <div>当前已完成总数</div>
                            </div>
                            <div className={styles.cardBoxNum}>53</div>
                        </div>
                    </LyCard>
                </Col>
            </Row>
        );
    }
}
