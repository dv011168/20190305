/*
 * @Description: 用户信息
 * @Author: qizc
 * @LastEditors: qizc
 * @Date: 2019-04-25 15:48:51
 * @LastEditTime: 2019-05-17 17:36:57
 */
import React from "react";
import { LyCard } from "components";
import styles from "./index.less";

export default class _UserInfo extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <LyCard isScroll={false} className={styles.box} height={250}>
                <div className={styles.imgBox}>
                    <img src={require("images/personal/personalInfo/tx.png")} />
                </div>
                <div className={styles.username}>秦韦德</div>
                <div className={styles.personalInfo}>
                    <div className={styles.item}>
                        <img
                            src={require("images/personal/personalInfo/jgh.png")}
                        />
                        <div>13005412</div>
                    </div>
                    <div className={styles.item}>
                        <img
                            src={require("images/personal/personalInfo/bm.png")}
                        />
                        <div>教工处</div>
                    </div>
                    <div className={styles.item}>
                        <img
                            src={require("images/personal/personalInfo/zc.png")}
                        />
                        <div>教授</div>
                    </div>
                    <div className={styles.item}>
                        <img
                            src={require("images/personal/personalInfo/zgxw.png")}
                        />
                        <div>博士</div>
                    </div>
                </div>
            </LyCard>
        );
    }
}
