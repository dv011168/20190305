import React, { Component } from "react";
import { connect } from "react-redux";
import { Route, Router, Link, Redirect, Switch } from "react-router-dom";
import { Menu, Icon, Button, Input, Table, Divider, Tag, Select, Layout } from 'antd';
import createHistory from "history/createHashHistory";
/*工具类*/
import { getSize } from "../../../../utils/util";
import Slider from "react-slick";


const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;
const Search = Input.Search;
const { Option } = Select;
var history = createHistory();
const { Header, Sider, Content } = Layout;


class formReviewAll extends Component {
  constructor(props) {
    super(props);
    this.state = {
      current:'1'
    };
  }
  render() {
    return(
        <div>all</div>
    );
  }
}

export default formReviewAll;