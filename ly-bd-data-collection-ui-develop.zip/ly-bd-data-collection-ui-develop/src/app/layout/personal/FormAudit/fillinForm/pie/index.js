class pie extends Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <div></div>
        );
    }
}

export default pie;