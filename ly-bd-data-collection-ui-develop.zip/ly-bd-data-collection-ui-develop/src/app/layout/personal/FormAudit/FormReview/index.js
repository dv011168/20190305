import React, { Component } from 'react';
import styles from "./index.less";
import NavigationBar from 'src/plugins/navigationBar';
import { Menu, Icon, Button, Input, Table, Divider, Tag, Select, Layout } from 'antd';
// import createHistory from "./node_modules/history/createHashHistory";
import { Link } from "react-router-dom";

const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;
const Search = Input.Search;
const { Option } = Select;


// var history = createHistory();
const { Header, Sider, Content } = Layout;
class FormReview extends Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 'form',
    };
  }


  handleClick = e => {
    console.log('click ', e);
    this.setState({
      current: e.key,
    });
  };


  //创建时间
  getSortData = (value, record) => {

    // console.log(value,record);
    console.log(value);
    let count = 0;
    if (record.stuname.indexOf(value) != -1) {
      // count++;
      return record;
    }
  }

  //筛选部门
  getSortBum = (value, record) => {
    // console.log(value);
    let count = 0;
    if (value === 'all') {
      return record
    } else {
      if (record.administration.indexOf(value) != -1) {
        // count++;
        return record;
      }
    }

  }

  //筛选状态
  getSortStatus = (value, record) => {
    if (value === 'all') {
      return record
    } else {
      if (record.status.indexOf(value) != -1) {
        // count++;
        return record;
      }
    }
  }

  //根据状态修改颜色
  getStatus = (value, record) => {
    // console.log(value);
    // console.log(record);
    if (value === '未完成') {
      return `<span style={{color:'red'}}>测试</span>`
    } else if (value === '已完成') {
      return `<span style={{color:'green'}}>测试</span>`
    }
  }

  render() {
    const columns = [
      {
        title: '表名',
        dataIndex: 'formName',
        key: 'formName',
        //   render: text => <a href="javascript:;">{text}</a>,
      },
      {
        title: '创建人',
        dataIndex: 'createBy',
        key: 'createBy',
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        filters: [
          {
            text: '三个月',
            value: 'threeM',
          },
          {
            text: '半年',
            value: 'sixM',
          },
          {
            text: '自定义',
            value: 'Submenu',
            children: [
              {
                text: '1年',
                value: 'oneY',
              },
              {
                text: '2年',
                value: 'twoY',
              },
            ],
          },
        ],
        // specify the condition of filtering result
        // here is that finding the name started with `value`
        onFilter: (value, record) => { return this.getSortData(value, record) },
        // sorter: (a, b) => a.name.length - b.name.length,
        // sortDirections: ['descend'],
        filterIcon: () => {
          return <Icon type="caret-down" />
        },
        filterMultiple: false,
      },
      {
        title: '主管部门',
        dataIndex: 'administration',
        key: 'administration',
        filters: [
          {
            text: '全部',
            value: 'all',
          },
          {
            text: '网络与信息技术中心',
            value: '网络与信息技术中心',
          },
          {
            text: '教务处',
            value: '教务处',
          },
          {
            text: '科研处',
            value: '科研处',
          },
        ],
        // specify the condition of filtering result
        // here is that finding the name started with `value`
        onFilter: (value, record) => { return this.getSortBum(value, record) },
        // sorter: (a, b) => a.name.length - b.name.length,
        // sortDirections: ['descend'],
        filterIcon: () => {
          return <Icon type="caret-down" />
        },
        // filterMultiple: false, 禁止多选
      },
      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        filters: [
          {
            text: '全部',
            value: 'all',
          },
          {
            text: '待审核',
            value: '待审核',
          },
          // {
          //   text: '进行中',
          //   value: '进行中',
          // },
          {
            text: '已审未结',
            value: '已审未结',
          },
          {
            text: '通过',
            value: '通过',
          },
          {
            text: '中断',
            value: '中断',
          },

        ],

        onFilter: (value, record) => { return this.getSortStatus(value, record) },

        filterIcon: () => {
          return <Icon type="caret-down" />
        },
        // filterMultiple: false,  //禁止多选
        // record: text => { <span style={{ backgroundColor: 'yellow  !important' }}>{text}</span> },

        //状态
        // render:(text, record) => this.getStatus(text,record)
        render: (text, record) => {

          if (text === '待审核') {
            return <div className={styles.status_pending}>待审核</div>
          } else if (text === '已审未结') {
            return <div className={styles.status_unreviewed}>已审未结</div>
          } else if (text === '通过') {
            return <div className={styles.status_by}>通过</div>
          } else if (text === '不通过') {
            return <div className={styles.status_fail}>不通过</div>
          } else if (text === '中断') {
            return <div className={styles.status_interrupt}>中断</div>
          }
          // else if(text ==='中断'){
          //   return <div className={styles.status_interrupt}>中断</div>
          // }
        },
      },
      {
        title: '操作',
        key: 'action',
        render: (text, record) => {

          // <span>
          //   <a href="javascript:;"> 审核</a>
          // </span>
          // console.log(text);
          // //  console.log("record",record);
          if (text.status === '待审核') {
            return (<span>
              {/* <a href="javascript:;">审核</a> */}
              {/* <a href="javascript:void(0);" onClick={() => this.editAction(record)}><Icon type="edit"></Icon><span style={{ padding: '2px' }}>审核</span></a> */}
              <Link to="formReview/list">
                <Icon type="edit"></Icon><span style={{ padding: '2px' }}>审核</span>
              </Link>
            </span>)
          } else if (text.status === '通过' || text.status === '不通过' || text.status === '已审未结') {
            return (
              <span>
                <a href="javascript:void(0);" style={{ color: '#0EBF41' }} onClick={() => this.readAction(record)}><Icon type="eye"></Icon><span style={{ padding: '2px' }}>查看</span></a>
                {/* <a href="javascript:;">查看</a> */}
              </span>)
          }

        },
      }
    ];



    const data = [
      {
        key: '1',
        formName: '学生会组织申请表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '科研处',
        status: '待审核'
      },
      {
        key: '2',
        formName: '班级信息收集表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '科研处',
        status: '中断'
      },
      {
        key: '3',
        formName: '校园车辆登记表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '教务处',
        status: '已审未结'
      },
      {
        key: '4',
        formName: '贫困生补助表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '教务处',
        status: '通过'
      },
      {
        key: '5',
        formName: '学工处人员登记表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '科研处',
        status: '已审未结'
      },
      {
        key: '6',
        formName: '留学生宿舍申报表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '科研处',
        status: '通过'
      },
      {
        key: '7',
        formName: '差旅费报备表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '科研处',
        status: '通过'
      },
      {
        key: '8',
        formName: '实验室设备登记表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '科研处',
        status: '不通过'
      },
      {
        key: '9',
        formName: '互联网+大赛报名表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '科研处',
        status: '中断'
      },
      {
        key: '10',
        formName: '差旅费报备表',
        createBy: '刘志宝',
        createTime: '03-02 09:05',
        administration: '科研处',
        status: '中断'
      },

    ];

    const rowSelection = {};
    const { collapsed, clientHeight } = this.state;
    return (

      <div className={styles.formReview_box}>

        {/* <div className={styles.title}> 当前位置：个人中心 > 表样审核</div> */}

        <NavigationBar />


        {/*   */}

        <div className={styles.Amenu}>

          <Menu onClick={this.handleClick} selectedKeys={[this.state.current]} mode="horizontal">
            <Menu.Item key="form">
              <Link to="formReview">
                <span>表样审核</span>
              </Link>

            </Menu.Item>
            <Menu.Item key="fillin">
              <Link to="fillinForm">
                <span>填表审核</span>
              </Link>

            </Menu.Item>
            <Menu.Item key="work">
              <Link to="">
                <span>任务审核</span>
              </Link>
            </Menu.Item>
          </Menu>
          <hr className={styles.hrN} />


        </div>

        <div className={styles.b_button}>
          {/* <button style={{backgroundColor:'#2CB0B5',color:'#fff'}}>全部</button>
          <button>待审核</button>
          <button>已审未结</button>
          <button>已审已结</button> */}
          <div className={styles._div_f}>全部</div>
          <div className={styles._div_m}>待审核</div>
          <div className={styles._div_m}>已审未结</div>
          <div className={styles._div_z}>已审已结</div>
          <div style={{ float: 'right', minWidth: '388px', height: '36px', marginRight: '20px' }}>
            <Search
              placeholder="请输入表名"
              enterButton="搜索"
              // size="large"
              onSearch={value => console.log(value)}
            />
          </div>
        </div>

        <div className={styles.tableTip}>
          <Icon type="info-circle" />
          <span>全部：10 项  待审核：2 项  已审未结：4 项  已审已结：4 项</span>
        </div>

        <div className={styles.tableData}>
          <Table columns={columns} dataSource={data} bordered={true}
            pagination={{
              // position:"both"
              showSizeChanger: true,
              showQuickJumper: true,
              total: 500,
              showTotal: () => { return `共50页` },    //显示多少条记录(total) => {return this.showTotald(total)},
            }} />
        </div>

        {/* <style jsx='true' global='true'>
          {`.ant-menu-horizontal > .ant-menu-item{
                        color: #666666
                    },
                    .ant-menu{
                        background-color:#cdcdcd
                    }
                    `
          }
          
        </style> */}
      </div>

    );
  }
}

export default FormReview;