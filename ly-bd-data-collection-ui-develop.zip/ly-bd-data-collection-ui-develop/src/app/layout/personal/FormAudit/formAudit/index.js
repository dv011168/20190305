import React, { Component } from 'react';
import styles from "./index.less";
import info from 'images/personal/formAudit/info.png';
import { Steps, Icon, Input, Button } from 'antd';
import checkAudit from 'images/personal/formAudit/checkAudit_b.png'
import finished from 'images/personal/formAudit/finished_s.png'
import sq from 'images/personal/formAudit/sq.png'   //收起
import sh from 'images/personal/formAudit/sh.png'  //审核

const { TextArea } = Input;
const Step = Steps.Step;




class formAudit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            
        };
    }

    getdeciption = (value) => {
        // alert();
        return (
            <div style={{height:'150px'}}>
                <span >提交</span>
                
                <span style={{display:'block'}} className={styles.span_one}>刘志宝（网络与信息技术中心）</span>
                {/* <br /> */}
                <span style={{display:'block'}}>2019-03-01 17:00</span>
            </div> 
        )
    }

    render() {
        return (
            <div className={styles.review_box}>
                <div className={styles.title}> 当前位置：个人中心 > 表样审核 > 审核</div>
                <hr className={styles.hr} />
                <div className={styles.bigbox}>
                    <div className={styles.formName}>班级信息收集表</div>
                    <div className={styles.formInfomation}>
                        <div className={styles.formTitle}>
                            <img src={info} /><span className={styles.t_span}>表单信息</span>
                        </div>

                        <div className={styles.f_h}>
                            <div className={styles.f_h_left}><span className={styles.span_one}>表单描述:</span><span className={styles.span_two}>本表用于收集班级基本信息。</span></div>
                            <div className={styles.f_h_right}><span className={styles.span_one}>部门:</span><span className={styles.span_two}>网络信息技术中心</span></div>
                        </div>
                        <div style={{ clear: 'both' }} className={styles.f_h}>
                            <div className={styles.f_h_left}><span className={styles.span_one}>状态:</span><span className={styles.span_two}>待审核</span></div>
                            <div className={styles.f_h_right}><span className={styles.span_one}>时间:</span><span className={styles.span_two}>2019-03-01 17:07:07</span></div>
                        </div>

                    </div>
                    <hr style={{ color: '#DDDDDD', opacity: '0.38' }} />
                    <div className={styles.formInfomation}>
                        <div style={{ padding: '40px 0 20px' }} className={styles.formTitle}>
                            <img src={info} /><span className={styles.t_span}>审核信息</span>
                        </div>
                        <div className={styles.pd}><span className={styles.span_one}>审核流程信息</span></div>
                        <div className={styles.pd}><span className={styles.span_one}>当前节点:</span><span className={styles.span_two}>周毛毛(待审核)</span></div>
                        <div className={styles.step}>
                            <Steps current={3}>
                                <Step status="finish" title="finish" description={this.getdeciption()} icon={<img src={finished} />} />
                                <Step status="finish" title="finish" description={<div style={{height:'150px'}}>通过<br /><span className={styles.span_one}>韩一芳（网络与信息技术中心）</span><br /><span className={styles.span_one}>同意</span><br /><span>2019-03-01 17:00</span></div>} icon={<img src={finished} />} />
                                <Step status="finish" title="finish" description={<div >通过<br /><span className={styles.span_one}>韩琛（网络与信息技术中心）</span><br /><span className={styles.span_one}>同意</span><br /><span>2019-03-01 17:00</span></div>} icon={<img src={finished} />} />
                                <Step status="wait" title="waiting" description="待审核" icon={<img src={checkAudit} />} />
                                {/* "通过 韩琛（网络与信息技术中心）同意" */}
                            </Steps>
                        </div>
                        <div className={styles.option}>
                            <TextArea placeholder="请填写审核意见" rows={8} />
                            {/* <Input type="textArea" /> */}
                        </div>
                        <div className={styles.option_btn}>
                            <button>退回</button>
                            <button style={{ backgroundColor: '#2cb0b5', color: '#fff' }}>通过</button>

                        </div>
                        <div>
                            <div className={styles.pd}>
                                <span className={styles.span_one}>表样信息</span>
                            </div>
                            <div style={{float:'right'}}><img src={sq}/><span style={{paddingLeft:'10px',color:'#2cb0b5'}}>收起</span></div>
                            <div className={styles.formDetail}>
                                {/* <TextArea placeholder="表单详情" rows={8} /> */}
                                <img src={sh}/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


export default formAudit;