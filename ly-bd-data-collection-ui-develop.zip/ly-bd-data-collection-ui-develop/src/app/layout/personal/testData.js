export default {
    unexamine_model: {
        title:'待审表样',
        staticNumber:'10',
        routerAddress:'',
        unexamine_data:[
            {
              key: '1',
              name: '学生会组织申请表',
              creater: '刘志宝',
              time: '03-12 09:05',
              department: '科研处',
              action:0
            },
            {
                key: '2',
                name: '班级信息收集表',
                creater: '刘志宝',
                time: '03-12 09:05',
                department: '网络与信息技术中心',
                action:0
            },
            {
                key: '3',
                name: '校园车辆登记',
                creater: '刘志宝',
                time: '03-12 09:05',
                department: '科研处',
                action:0
            },
            {
                key: '4',
                name: '学工处人员登记',
                creater: '刘志宝',
                time: '03-12 09:05',
                department: '网络与信息技术中心',
                action:0
            },
            {
                key: '5',
                name: '贫困生补助',
                creater: '刘志宝',
                time: '03-12 09:05',
                department: '网络与信息技术中心',
                action:0
            },
        ]
    },
    unexamine_table: {
        title:'待审填表',
        staticNumber:'10',
        routerAddress:'',
        unexamine_data:[
            {
                key: '1',
                name: '学生会组织申请表',
                creater: '刘志宝',
                time: '03-12 09:05',
                department: '科研处',
                action:0
              },
              {
                  key: '2',
                  name: '班级信息收集表',
                  creater: '刘志宝',
                  time: '03-12 09:05',
                  department: '网络与信息技术中心',
                  action:0
              },
              {
                  key: '3',
                  name: '校园车辆登记',
                  creater: '刘志宝',
                  time: '03-12 09:05',
                  department: '科研处',
                  action:0
              },
              {
                  key: '4',
                  name: '学工处人员登记',
                  creater: '刘志宝',
                  time: '03-12 09:05',
                  department: '网络与信息技术中心',
                  action:0
              },
              {
                  key: '5',
                  name: '贫困生补助',
                  creater: '刘志宝',
                  time: '03-12 09:05',
                  department: '网络与信息技术中心',
                  action:0
              },
        ]
    },
    unexamine_task: {
        title:'待审任务',
        staticNumber:'10',
        routerAddress:'/personal/taskExamine',
        unexamine_data:[
            {
              key: '1',
              name: '2019年学生信息核对与补录',
              department: '刘志宝',
              time: '2019-06-12',
              completion: 15,
              action:0
            },
            {
                key: '2',
                name: '2019年教职工基础信息采集',
                department: '刘志宝',
                time: '2019-06-12',
                completion: 50,
                action:0
            },
            {
                key: '3',
                name: '2019年高基表数据采集',
                department: '刘志宝',
                time: '2019-06-12',
                completion: 60,
                action:0
            },
            {
                key: '4',
                name: '2019年状态数据采集',
                department: '刘志宝',
                time: '2019-06-12',
                completion: 70,
                action:0
            },
            {
                key: '5',
                name: '2019年本科评估数据采集',
                department: '刘志宝',
                time: '2019-06-12',
                completion: 80,
                action:0
            },
        ],
    },
    personalBaseData:{
        temperature:'29℃',
        weather:'晴 东南风3-5级 16-29℃',
        pmValue:'PM2.5值：82 良',
        user_name:'枣子哥',
        UserImg:'../../../../assets/images/personal/user.png',
        personalData:[
            {
                image:'../../../../assets/images/personal/job_number.png',
                text:20190313
            },
            {
                image:'../../../../assets/images/personal/department.png',
                text:'学工处'
            },
            {
                image:'../../../../assets/images/personal/title.png',
                text:'教授'
            },
            {
                image:'../../../../assets/images/personal/degree.png',
                text:'博士'
            }
        ],
    },
    barData : {
        daily:[
            ['数量', '当天'],
            ['表样审核', 3],
            ['填表审核', 5],
            ['任务审核', 2],
        ],
        weekly:[
            ['数量', '本周'],
            ['表样审核', 30],
            ['填表审核', 59],
            ['任务审核', 20],
        ],
        monthly:[
            ['数量', '本月'],
            ['表样审核', 50],
            ['填表审核', 210],
            ['任务审核', 40],               
        ]
    },
    examineSituation:[{
        title:'表样审核',
        staticNumber:'100',
        subData:[{
            image:'../../../../assets/images/personal/unexamine.png',
            title:'待审核',
            staticNumber:'10'
        },
        {
            image:'../../../../assets/images/personal/examining.png',
            title:'已审未结',
            staticNumber:'20'
        },
        {
            image:'../../../../assets/images/personal/examined.png',
            title:'已审已结',
            staticNumber:'70'
        }],
    },
    {
        title:'表单审核',
        staticNumber:'260',
        subData:[{
            image:'../../../../assets/images/personal/unexamine2.png',
            title:'待审核',
            staticNumber:'10'
        },
        {
            image:'../../../../assets/images/personal/examining2.png',
            title:'已审未结',
            staticNumber:'180'
        },
        {
            image:'../../../../assets/images/personal/examined2.png',
            title:'已审已结',
            staticNumber:'70'
        }],
    },
    {
        title:'任务审核',
        staticNumber:'280',
        subData:[{
            image:'../../../../assets/images/personal/unexamine3.png',
            title:'待审核',
            staticNumber:'10'
        },
        {
            image:'../../../../assets/images/personal/examining3.png',
            title:'进行中',
            staticNumber:'150'
        },
        {
            image:'../../../../assets/images/personal/examined3.png',
            title:'已完成',
            staticNumber:'120'
        }],
    }]
}