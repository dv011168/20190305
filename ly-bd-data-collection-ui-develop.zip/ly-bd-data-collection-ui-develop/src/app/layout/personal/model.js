
export default {
    namespace: "personal",
    state: {
        data: []
    },
    effects: {
        
    },
    reducers: {
       
    }
};
