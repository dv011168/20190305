import React from "react";
import styles from "./index.less";
import testData from './testData'
import {Row, Col } from 'antd';
import PersonalCard from "./commonents/PersonalCard/index"
import TotalSituationCard from "./commonents/TotalSituationCard/index"
import ExamineSituationCard from "./commonents/ExamineSituationCard/index"
import FlowEnterChart from "./commonents/FlowEnterChart/index"
import ExamineTableCard from "./commonents/ExamineTableCard/index"

class PersonalCenter extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          };
    };
    render() {
        return (
            <div className={styles.personal}>
                <Row gutter={8}>
                    <Col span={3} />
                    <Col span={5} >
                        <PersonalCard information={testData.personalBaseData}></PersonalCard>
                        <TotalSituationCard data={testData.examineSituation}></TotalSituationCard>
                        <ExamineSituationCard data={testData.barData}></ExamineSituationCard>
                    </Col>
                    <Col span={13} >
                        <FlowEnterChart></FlowEnterChart>
                        <ExamineTableCard examineModelData={testData.unexamine_model} examineTableData={testData.unexamine_table} examineTaskData={testData.unexamine_task}>
                        </ExamineTableCard>
                    </Col>
                    <Col span={3}/>
                </Row>              
            </div>
        );
    }
}


export default PersonalCenter;
