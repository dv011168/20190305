import React from "react";
import {Divider,Progress} from 'antd';
import ExamineTable from './ExamineTable'

class ExamineTalbeCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          };
    };
    render() {
        const examineModelData=this.props.examineModelData;
        const examineTableData=this.props.examineTableData;
        const examineTaskData=this.props.examineTaskData;

        return (
            <div>
                <ExamineTable data={examineModelData} coloums={columns4UnexamineModel}></ExamineTable>
                <ExamineTable data={examineTableData} coloums={columns4UnexamineTable}></ExamineTable>
                <ExamineTable data={examineTaskData} coloums={columns4UnexamineTask}></ExamineTable>
            </div>
            
        );
    }
}

const columns4UnexamineModel = [
    {
      title: '表名',
      dataIndex: 'name',
      key: 'name',
      align:'center'
    },
    {
      title: '创始人',
      dataIndex: 'creater',
      key: 'creater',
      align:'center'
    },
    {
      title: '创建时间',
      dataIndex: 'time',
      key: 'time',
      align:'center'
    },
    {
      title: '主管部门',
      key: 'department',
      dataIndex: 'department',
      align:'center'
    },
    {
      title: '操作',
      key: 'action',
      dataIndex: 'action',
      align:'center',
      render: (text, record) => {
        if(text===0){
            return (
              <span>
                <a href="javascript:;">审核</a>
              </span>
            );
        }else if(text===1){
            return (
              <span>
                  <a href="javascript:;">查看</a>
              </span>
            )
        }else{
          return (
            <span>
              <a href="javascript:;">审核</a>
              <Divider type="vertical" />
              <a href="javascript:;">查看</a>
            </span>
          );
        }
      },  
    },
  ];
  const columns4UnexamineTable = [
    {
      title: '表名',
      dataIndex: 'name',
      key: 'name',
      align:'center'
    },
    {
      title: '提交人',
      dataIndex: 'creater',
      key: 'creater',
      align:'center'
    },
    {
      title: '时间',
      dataIndex: 'time',
      key: 'time',
      align:'center'
    },
    {
      title: '来源部门',
      key: 'department',
      dataIndex: 'department',
      align:'center'
    },
    {
      title: '操作',
      key: 'action',
      dataIndex: 'action',
      align:'center',
      render: (text, record) => {
        if(text===0){
            return (
              <span>
                <a href="javascript:;">审核</a>
              </span>
            );
        }else if(text===1){
            return (
              <span>
                  <a href="javascript:;">查看</a>
              </span>
            )
        }else{
          return (
            <span>
              <a href="javascript:;">审核</a>
              <Divider type="vertical" />
              <a href="javascript:;">查看</a>
            </span>
          );
        }
      },      
    },
  ];
  const columns4UnexamineTask = [
    {
      title: '任务名称',
      dataIndex: 'name',
      key: 'name',
      align:'center'
    },
    {
      title: '截止日期',
      dataIndex: 'time',
      key: 'time',
      align:'center'
    },
    {
      title: '发起部门',
      key: 'department',
      dataIndex: 'department',
      align:'center'
    },
    {
        title: '完成度',
        key: 'completion',
        dataIndex: 'completion',
        align:'center',
        render: (text, record) => {
          return (
            <div style={{marginLeft:'30%',width: '120px' }}>
                <Progress percent={text} size="small"/>
            </div>
          )
        }, 
      },    
    {
      title: '操作',
      key: 'action',
      dataIndex: 'action',
      align:'center',
      render: (text, record) => {
        if(text===0){
            return (
              <span>
                <a href="javascript:;">审核</a>
              </span>
            );
        }else if(text===1){
            return (
              <span>
                  <a href="javascript:;">查看</a>
              </span>
            )
        }else{
          return (
            <span>
              <a href="javascript:;">审核</a>
              <Divider type="vertical" />
              <a href="javascript:;">查看</a>
            </span>
          );
        }
      }, 
    },
  ];

export default ExamineTalbeCard;