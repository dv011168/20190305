import React from "react";
import styles from "./index.less";
import {Card,Table} from 'antd';
import { Link } from "react-router-dom";

class ExamineTalbe extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          };
    };
    render() {
        const data = this.props.data;
        const coloums = this.props.coloums;
        return (
            <div>
                <Card 
                    className={styles.examineTableCard} 
                    bordered={false} 
                    cover={
                        <div className={styles.titleZone}>
                            <div style={{position:'relative',float: 'left'}}><span>{data.title}</span></div>
                            <div className={styles.generalStatic}>{data.staticNumber}</div>
                            <div className={styles.maotto}><a><Link to={data.routerAddress}>更多>></Link></a></div>
                        </div>
                    }
                    bodyStyle={{padding: 0}}>
                    <hr></hr>
                    <Table columns={coloums} dataSource={data.unexamine_data} pagination={false}/>
                </Card>
            </div>
            
        );
    }
}

export default ExamineTalbe;