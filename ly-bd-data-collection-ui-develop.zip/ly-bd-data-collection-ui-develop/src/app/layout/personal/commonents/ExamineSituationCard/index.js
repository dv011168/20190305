import React from "react";
import styles from "./index.less";
import {Card,Select} from 'antd';
import ReactEchartsCore from "echarts-for-react/lib/core";
import echarts from "echarts/lib/echarts";
import "echarts/lib/chart/bar";
import "echarts/lib/component/tooltip";
import "echarts/lib/component/title";

class ExamineSituationCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            chartStyle:'weekenly'
        };
    };
    getOption = (data) => {
		const option = {
			legend: {},
			tooltip: {},
			dataset: {
				source: data
			},
			xAxis: {type: 'category',barPercentage: 0.3},
            yAxis: {},
			// Declare several bar series, each will be mapped
			// to a column of dataset.source by default.
			series: [
				{
                    type: 'bar',
                    barWidth : 30,
                    itemStyle:{
                        normal: {
                            color:'rgba(83,173,245,1)'
                        }
                    }
                },
            ],
            textStyle:{
                color: 'rgba(102,102,102,1)'
            },
            axisPointer:{
                label:{
                    width:'5%'
                }
            }
		};

		return option;
    }

    onSelectChange = value => {
        this.setState({
            chartStyle: value,
        });
    };

    render() {
        const chartStyle = this.state.chartStyle;
        var data;
        switch(chartStyle){
            case 'daily' :data = this.props.data.daily;break;
            case 'weekenly' :data = this.props.data.weekly;break;
            case 'monthly' :data = this.props.data.monthly;break;
        }
        return (
            <div>
                <Card 
                title="审核情况" 
                className={styles.examineeSituationCard} 
                bordered={false} 
                headStyle={{color: 'rgba(44, 176, 181, 1)','font-size': '18px','font-weight': 'bold'}} 
                extra={<div className={styles.generalStatic}>
                            <Select size="small" defaultValue="weekenly" onSelect={this.onSelectChange}>
                                <Option value="monthly">本月</Option>
                                <Option value="weekenly">本周</Option>
                                <Option value="daily">当天</Option>
                            </Select>
                        </div>}>
                    <div style={{marginTop:'-50px'}}>
                        <ReactEchartsCore
                            echarts={echarts}
                            option={this.getOption(data)}
                            notMerge={true}
                            lazyUpdate={true}
                        />
                    </div>
                </Card>
            </div>
            
        );
    }
}

export default ExamineSituationCard;