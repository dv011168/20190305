import React from "react";
import styles from "./index.less";
import {Card} from 'antd';
import { Link } from "react-router-dom";

class FlowEnterChart extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          };
    };
    render() {
        return (
            <div>
                <Card className={styles.subFlowCard} bordered={false} bodyStyle={{padding: 0}}>
                    <div style={{height:1}}/>
                    <div style={{marginTop:'71px'}}>
                        <hr></hr>
                    </div>
                    <div style={{width:'100%',marginLeft:'4%'}}>
                        <div className={styles.imgSmall}>
                            <img src="../../../../assets/images/personal/flowImage/1-modelSetting.png"></img><br/>
                            <div className={styles.text}>报表配置</div>
                        </div>
                        <div className={styles.imgBig}>
                            <img src="../../../../assets/images/personal/flowImage/2-modelExamine.png"></img>
                            <div className={styles.text}>表样审核</div>
                        </div>
                        <div className={styles.imgSmall}>
                            <img src="../../../../assets/images/personal/flowImage/3-modelPublish.png"></img>
                            <div className={styles.text}>报表发布</div>
                        </div>
                        <div className={styles.imgSmall}>
                            <img src="../../../../assets/images/personal/flowImage/4-fullInTable.png"></img>
                            <div className={styles.text}>用户填表</div>
                        </div>
                        <div className={styles.imgBig}>
                            <img src="../../../../assets/images/personal/flowImage/5-tableExamine.png"></img>
                            <div className={styles.text}>填表审核</div>
                        </div>
                        <div className={styles.imgSmall}>
                            <img src="../../../../assets/images/personal/flowImage/6-taskArrange.png"></img>
                            <div className={styles.text}>采集任务下发</div>
                        </div>
                        <div className={styles.imgSmall}>
                            <img src="../../../../assets/images/personal/flowImage/7-taskReport.png"></img>
                            <div className={styles.text}>任务上报</div>
                        </div>
                        <div className={styles.imgBig}>
                            <Link to="personal/taskExamine">
                                <img src="../../../../assets/images/personal/flowImage/8-taskExamine.png"></img>
                                <div className={styles.text}>任务审核</div>
                            </Link>
                        </div>
                        <div className={styles.imgSmall}>
                            <img src="../../../../assets/images/personal/flowImage/9-collection.png"></img>
                            <div className={styles.text}>填表归档</div>
                        </div>
                    </div> 
                </Card>
            </div>
        );
    }
}

export default FlowEnterChart;