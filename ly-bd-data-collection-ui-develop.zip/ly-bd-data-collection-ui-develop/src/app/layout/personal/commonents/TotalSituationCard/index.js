import React from "react";
import styles from "./index.less";
import {Card} from 'antd';

class TotalSituationCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          };
    };
    render() {
        const data = this.props.data;
        return (
            <div>
                <Card 
                    title="总体情况" 
                    bordered={false} 
                    className={styles.totalSituationCard}
                    headStyle={{color: 'rgba(44, 176, 181, 1)','font-size': '18px','font-weight': 'bold'}}>

                    <BuildCard examineSituation={data}></BuildCard>
                </Card>
            </div>
            
        );
    }
}

function BuildCard(props){
    return(
        props.examineSituation.map(
            (item)=>{
                return (
                    <div className={styles.examineSituation}>
                        <div>
                            <span>{item.title}</span>
                            <div className={styles.generalStatic}>{item.staticNumber}</div>
                        </div>
                        <div>
                            {item.subData.map(
                                (item)=>{
                                    return(
                                        <div className={styles.examineZone}>
                                            <div className={styles.bgimage}><img src={item.image}></img></div>
                                            <span>{item.title}</span>
                                            <div className={styles.staticNumber}>{item.staticNumber}</div>
                                        </div>                                                                
                                    );
                                }
                            )}
                        </div>
                    </div>
                );
            }
        )
    );

}

export default TotalSituationCard;