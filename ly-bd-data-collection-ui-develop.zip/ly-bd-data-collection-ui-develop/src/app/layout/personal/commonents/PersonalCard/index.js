import React from "react";
import styles from "./index.less";
import {Card, Button} from 'antd';

function BaseDataUnit(props) {
    return (
        <div className={styles.base_data}>
            <img src={props.image} alt="data_img"></img><br/>
            <span>{props.text}</span>
        </div>
    );
};

class PersonalCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          };
    };
    render() {
        const information = this.props.information;
        return (
            <div>
                <Card className={styles.personal_card} bodyStyle={{padding: 0,overflow:'hidden'}} bordered={false} height="300px">
                    <div style={{height:'150px'}}>
                        <div className={styles.upper_zone}>
                            <div className={styles.temperature_text}>
                                <span>{information.temperature}</span>
                            </div>
                            <div className={styles.weather_text}>
                                <span>{information.weather}</span><br/> 
                                <span>{information.pmValue}</span>
                            </div>
                        </div>
                        <div className={styles.ellipse}/>
                        <div className={styles.user_circle}>
                            <img src={information.UserImg} alt="userImage"></img>
                            <span>{information.user_name}</span>
                        </div>
                        <div style={{width:'100%',marginTop:'-70px'}}><div className={styles.circle1}/></div>
                        <div style={{width:'100%',marginTop:'-100px'}}><div className={styles.circle2}/></div>
                        <div style={{width:'100%',marginTop:'-80px'}}><div className={styles.circle3}/></div>
                    </div>
                    <div style={{height:'150px'}}>
                        <div className={styles.personal_information}>
                            {information.personalData.map(
                                (item)=>{
                                    return <BaseDataUnit image={item.image} text={item.text}/>
                                }
                            )}
                        </div>
                        <Button type="primary" className={styles.enter_button}>查看部门个人资料</Button>
                    </div>
                </Card>
            </div>
            
        );
    }
}


export default PersonalCard;