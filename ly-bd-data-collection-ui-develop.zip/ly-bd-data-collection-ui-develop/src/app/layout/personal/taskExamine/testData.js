export default {
    all_task_data:[
        {
          key: '1',
          name: '2019年本科评估数据采集任务',
          creater: '刘志宝',
          time: '2019-06-12',
          department: '科研处',
          action:1,
          fullCompletion:20,
          examineCompletion:50,
          subRow:[{
            department:'教务处（3份）  ',
            director:'负责人：李四',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          },
          {
            department:'教工处（2份）',
            director:'负责人：张三',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          },
          {
            department:'科研处（3份）',
            director:'负责人：王五',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          }                    
        ]
        },
        {
            key: '2',
            name: '2019年4月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1

        },
        {
            key: '3',
            name: '2019年3月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1
        },
        {
            key: '4',
            name: '2019年2月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1
        },
        {
            key: '5',
            name: '2018学年信息收集',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1
        },
        {
            key: '6',
            name: '2019年1月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1
        },
        {
              key: '7',
              name: '贫困生资料收集',
              creater: '刘志宝',
              time: '2019-06-12',
              department: '科研处',
              fullCompletion:20,
              examineCompletion:50,
              action:2
        },
        {
              key: '8',
              name: '2017学年信息收集',
              creater: '刘志宝',
              time: '2019-06-12',
              department: '科研处',
              fullCompletion:20,
              examineCompletion:50,
              action:2
        },
        {
              key: '9',
              name: '留学生资料收集',
              creater: '刘志宝',
              time: '2019-06-12',
              department: '科研处',
              fullCompletion:20,
              examineCompletion:50,
              action:2
        },
        {
              key: '10',
              name: '港澳台交换生资料收集',
              creater: '刘志宝',
              time: '2019-06-12',
              department: '科研处',
              fullCompletion:20,
              examineCompletion:50,
              action:2
        },
        {
            key: '11',
            name: '2017学年资料收集',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:2
      }
    ],
    three_month_task_data:[
        {
          key: '1',
          name: '2019年本科评估数据采集任务',
          creater: '刘志宝',
          time: '2019-06-12',
          department: '科研处',
          action:1,
          fullCompletion:20,
          examineCompletion:50,
          subRow:[{
            department:'教务处（3份）  ',
            director:'负责人：李四',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          },
          {
            department:'教工处（2份）',
            director:'负责人：张三',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          },
          {
            department:'科研处（3份）',
            director:'负责人：王五',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          }                    
        ]
        },
    ],
    half_year_task_data:[
        {
          key: '2',
          name: '2019年本科评估数据采集任务',
          creater: '刘志宝',
          time: '2019-06-12',
          department: '科研处',
          action:1,
          fullCompletion:20,
          examineCompletion:50,
          subRow:[{
            department:'教务处（3份）  ',
            director:'负责人：李四',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          },
          {
            department:'教工处（2份）',
            director:'负责人：张三',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          },
          {
            department:'科研处（3份）',
            director:'负责人：王五',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          }                    
        ]
        },
        {
            key: '1',
            name: '2019年本科评估数据采集任务',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            action:1,
            fullCompletion:20,
            examineCompletion:50,
            subRow:[{
              department:'教务处（3份）  ',
              director:'负责人：李四',
              situation:{
                  unpush:'未提交：1',
                  unexamine:'待审核：1',
                  examining:'审核中：1',
                  complate:'已完成：1'
              },
              fullPercent:20,
              examinePercent:50
            },
            {
              department:'教工处（2份）',
              director:'负责人：张三',
              situation:{
                  unpush:'未提交：1',
                  unexamine:'待审核：1',
                  examining:'审核中：1',
                  complate:'已完成：1'
              },
              fullPercent:20,
              examinePercent:50
            },
            {
              department:'科研处（3份）',
              director:'负责人：王五',
              situation:{
                  unpush:'未提交：1',
                  unexamine:'待审核：1',
                  examining:'审核中：1',
                  complate:'已完成：1'
              },
              fullPercent:20,
              examinePercent:50
            }                    
          ]
          },
    ],
    unexamine_task_data:[
        {
          key: '1',
          name: '2019年本科评估数据采集任务',
          creater: '刘志宝',
          time: '2019-06-12',
          department: '科研处',
          action:1,
          fullCompletion:20,
          examineCompletion:50,
          subRow:[{
            department:'教务处（3份）  ',
            director:'负责人：李四',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          },
          {
            department:'教工处（2份）',
            director:'负责人：张三',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          },
          {
            department:'科研处（3份）',
            director:'负责人：王五',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:50
          }                    
        ]
        },
        {
            key: '2',
            name: '2019年4月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1

        },
        {
            key: '3',
            name: '2019年3月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1
        },
        {
            key: '4',
            name: '2019年2月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1
        },
        {
            key: '5',
            name: '2018学年信息收集',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1
        },
        {
            key: '6',
            name: '2019年1月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:50,
            action:1
        },
        {
              key: '7',
              name: '贫困生资料收集',
              creater: '刘志宝',
              time: '2019-06-12',
              department: '科研处',
              fullCompletion:20,
              examineCompletion:50,
              action:2
        }
    ],
    exmining_task_data:[
        {
          key: '1',
          name: '2019年本科评估数据采集任务',
          creater: '刘志宝',
          time: '2019-06-12',
          department: '科研处',
          action:1,
          fullCompletion:20,
          examineCompletion:100,
          subRow:[{
            department:'教务处（3份）  ',
            director:'负责人：李四',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:100
          },
          {
            department:'教工处（2份）',
            director:'负责人：张三',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:100
          },
          {
            department:'科研处（3份）',
            director:'负责人：王五',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:20,
            examinePercent:100
          }                    
        ]
        },
        {
            key: '2',
            name: '2019年4月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:100,
            action:1

        },
        {
            key: '3',
            name: '2019年3月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:100,
            action:1
        },
        {
            key: '4',
            name: '2019年2月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:100,
            action:1
        },
        {
            key: '5',
            name: '2018学年信息收集',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:100,
            action:1
        },
        {
            key: '6',
            name: '2019年1月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:20,
            examineCompletion:100,
            action:1
        }
    ],
    exmined_task_data:[
        {
          key: '1',
          name: '2019年本科评估数据采集任务',
          creater: '刘志宝',
          time: '2019-06-12',
          department: '科研处',
          action:1,
          fullCompletion:100,
          examineCompletion:100,
          subRow:[{
            department:'教务处（3份）  ',
            director:'负责人：李四',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:100,
            examinePercent:100
          },
          {
            department:'教工处（2份）',
            director:'负责人：张三',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:100,
            examinePercent:100
          },
          {
            department:'科研处（3份）',
            director:'负责人：王五',
            situation:{
                unpush:'未提交：1',
                unexamine:'待审核：1',
                examining:'审核中：1',
                complate:'已完成：1'
            },
            fullPercent:100,
            examinePercent:100
          }                    
        ]
        },
        {
            key: '2',
            name: '2019年4月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:100,
            examineCompletion:100,
            action:1

        },
        {
            key: '3',
            name: '2019年3月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:100,
            examineCompletion:100,
            action:1
        },
        {
            key: '4',
            name: '2019年2月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:100,
            examineCompletion:100,
            action:1
        },
        {
            key: '5',
            name: '2018学年信息收集',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:100,
            examineCompletion:100,
            action:1
        },
        {
            key: '6',
            name: '2019年1月月报',
            creater: '刘志宝',
            time: '2019-06-12',
            department: '科研处',
            fullCompletion:100,
            examineCompletion:100,
            action:1
        }
    ],
}