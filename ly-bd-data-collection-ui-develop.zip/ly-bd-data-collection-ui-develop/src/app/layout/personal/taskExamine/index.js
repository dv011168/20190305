import React, { Component } from 'react';
import styles from "./index.less";
import { Menu, Icon, Input, Table, Progress, Row, Col, Radio, Dropdown } from 'antd';
import testData from './testData'
import { Link } from "react-router-dom";
const Search = Input.Search;

class TaskExamine extends Component {
  constructor(props) {
    super(props);
    this.state = {
        currentRouter: 'task',
        radioValue:'all',
        tableData:testData.all_task_data
    };
  }

  selectRouter = e => {
    this.setState({
        currentRouter: e.key,
    });
  };

  onClickRadio = item => {
    var tableData;
    switch(item.target.value){
        case 'all':
            tableData = testData.all_task_data;
            break;
        case 'unexamine':
            tableData = testData.unexamine_task_data;
            break;
        case 'exmining':
            tableData = testData.exmining_task_data;
            break;
        case 'exmined':
            tableData = testData.exmined_task_data;
            break;
    }
    this.setState({
         radioValue: item.target.value,
         tableData : tableData
    });
  };
  
  columnsForAllTask = [
    {
      title: '任务名',
      dataIndex: 'name',
      key: 'name',
      align:'center'
    },
    {
      title: '截止日期',
      dataIndex: 'time',
      key: 'time',
      align:'center',
      filters: [{ text: 'Joe', value: 'Joe' }, { text: 'Jim', value: 'Jim' }],
      filterIcon:()=>{return <Icon type="caret-down" />},
      filterDropdown:()=>{
        return( 
            <Menu onClick={(item)=>{
                switch(item.key){
                    case 'three-month':
                        this.setState({
                            tableData:testData.three_month_task_data
                        });
                        break;
                    case 'half-year':
                        this.setState({
                            tableData:testData.half_year_task_data
                        });
                        break;
                }
            }}>
                <Menu.Item key="three-month">近三个月</Menu.Item>
                <Menu.Item key="half-year">近半年</Menu.Item>
                <Menu.Item key="custom">自定义</Menu.Item>
            </Menu>           
        )}
    },
    {
      title: '发起部门',
      key: 'department',
      dataIndex: 'department',
      align:'center',
      filterIcon:()=>{return <Icon type="caret-down" />},
      filterDropdown:()=>{
        return( 
            <Menu>
                <Menu.Item key="1">科研处</Menu.Item>
                <Menu.Item key="2">教务处</Menu.Item>
            </Menu>           
        )}
    },
    {
        title: '填写速度',
        key: 'fullCompletion',
        dataIndex: 'fullCompletion',
        align:'center',
        render:(text,record)=>{
            return(
                <div style={{width: '60%' ,marginLeft:'20%',marginRight:'20%'}}>
                    <Progress percent={text} size="small"/>
                </div>
        )}
    },
    {
        title: '审核进度',
        key: 'examineCompletion',
        dataIndex: 'examineCompletion',
        align:'center',
        render:(text,record)=>{
            return(
                <div style={{width: '60%' ,marginLeft:'20%',marginRight:'20%'}}>
                    <Progress percent={text} size="small" strokeColor="Green"/>
                </div>
            )}
    },
    {
      title: '操作',
      key: 'action',
      align:'center',
      render: (text, record) => {
          if(text.action===1){
              return (
                <span>
                    <a href="javascript:;">审核</a>
                </span>
              );
          }else{
              return (
                (
                    <span>
                        <a href="javascript:;">查看</a>
                    </span>
                  )
              )
          }
      },
    },
  ]
  render() {
      const radioValue = this.state.radioValue;
      
      return (
        <div className={styles.taskExamine}>
            <div className={styles.navigation}>
                <div className={styles.navigation1}>当前位置：</div>
                <div className={styles.navigation1}>个人中心<span style={{marginLeft:'5px',marginRight:'5px'}}>></span></div>
                <div className={styles.navigation2}>任务审核</div>
            </div>
            <div className={styles.Amenu}>
                <Menu onClick={this.selectRouter} selectedKeys={this.state.currentRouter} mode="horizontal">
                    <Menu.Item key="model">表样审核</Menu.Item>
                    <Menu.Item key="table"><Link to="/formReview"></Link>填表审核</Menu.Item>
                    <Menu.Item key="task">任务审核</Menu.Item>
                </Menu>
                <hr className={styles.hrN} />
            </div>
            <div className={styles.Bmenu}>
                <Radio.Group value={radioValue} onChange={this.onClickRadio} style={{ marginBottom: 16 }} buttonStyle="solid">
                    <Radio.Button value="all">全部</Radio.Button>
                    <Radio.Button value="unexamine">待审核</Radio.Button>
                    <Radio.Button value="exmining">进行中</Radio.Button>
                    <Radio.Button value="exmined">已完成</Radio.Button>
                </Radio.Group>
                <div style={{ float: 'right', minWidth: '388px', height: '36px'}}>
                    <Search
                    placeholder="请输入表名"
                    enterButton="搜索"
                    onSearch={value => console.log(value)}
                    />
                </div>
            </div>

            <AllTaskTable tableData={this.state.tableData} columns={this.columnsForAllTask}></AllTaskTable>

        </div>
      );
  }
}

function AllTaskTable(props){
    const tableData = props.tableData;
    const tableLength = Object.keys(tableData).length;
    const tablePage = Object.keys(tableData).length%10 == 0 ? parseInt(Object.keys(tableData).length/10) : parseInt(Object.keys(tableData).length/10 + 1);
    return (
        <div>
            <div className={styles.tableTip}>
                <Icon type="info-circle" style={{color:'rgba(44, 176, 181, 1)'}}/>
                <span>全部：16个任务,<span style={{color:'rgba(254, 99, 115, 1)'}}>未完成11项,</span>已完成5项。</span>
            </div>
            <div style={{marginTop: '6px'}}>
                <Table 
                columns={props.columns} 
                dataSource={tableData} 
                pagination={{showSizeChanger: true,showQuickJumper: true,total: tableLength,showTotal: () => { return '共'+tablePage +'页' },}}
                expandedRowRender={record => <SubTableRwo subRowData={record.subRow}></SubTableRwo>}
                expandIcon={CustomExpandIcon}
                />
            </div>
        </div>
    )
}

function CustomExpandIcon(props) {
    var icon;
    if (props.expanded) {
        icon = <Icon type="caret-up" />;
    } else {
        icon = <Icon type="caret-down" />;
    }
    return (
        <div onClick={e => props.onExpand(props.record, e)}>{icon}</div>
    );
  }

function SubTableRwo(props){
    const subRowDataArray = props.subRowData;
    if(subRowDataArray==null){return null}
    return (
        <div>
            {subRowDataArray.map(
                (subRowData)=>{
                    return (
                        <div>
                            <Row gutter={8} style={{textAlign:"center"}}>
                                <Col span={3}>
                                    {subRowData.department}
                                </Col>
                                <Col span={3} >
                                    {subRowData.director}
                                </Col>
                                <Col span={8}>
                                    <span style={{marginLeft:'20px'}}>{subRowData.situation.unpush}</span>
                                    <span style={{marginLeft:'20px'}}>{subRowData.situation.unexamine}</span>
                                    <span style={{marginLeft:'20px'}}>{subRowData.situation.examining}</span>
                                    <span style={{marginLeft:'20px'}}>{subRowData.situation.complate}</span>
                                </Col>
                                <Col span={4}>
                                    <div style={{width: '50%',marginLeft:'25%'}}>
                                        <Progress percent={subRowData.fullPercent} size="small"/>
                                    </div>
                                </Col>
                                <Col span={4}>
                                    <div style={{width: '50%',marginLeft:'25%'}}>
                                        <Progress percent={subRowData.examinePercent} size="small" strokeColor="Green"/>
                                    </div>
                                </Col>
                                <Col span={2}>
                                </Col>
                            </Row>
                        </div>
                    );
                }
            )}
        </div>
    );
}

const menu = (
    <Menu>
      <Menu.Item>
        <a target="_blank" rel="noopener noreferrer" href="http://www.alipay.com/">
          1st menu item
        </a>
      </Menu.Item>
      <Menu.Item>
        <a target="_blank" rel="noopener noreferrer" href="http://www.taobao.com/">
          2nd menu item
        </a>
      </Menu.Item>
      <Menu.Item>
        <a target="_blank" rel="noopener noreferrer" href="http://www.tmall.com/">
          3rd menu item
        </a>
      </Menu.Item>
    </Menu>
  );

export default TaskExamine;