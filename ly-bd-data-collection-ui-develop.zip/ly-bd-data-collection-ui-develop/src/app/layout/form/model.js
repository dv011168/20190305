
export default {
    namespace: "form",
    state: {
        data: []
    },
    effects: {
        
    },
    reducers: {
       
    }
};
