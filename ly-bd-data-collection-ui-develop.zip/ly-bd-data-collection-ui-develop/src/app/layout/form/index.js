import React from "react";
import styles from "./index.less";

class FormHall extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <div  className={styles.box}>
                <h1 >表单大厅</h1>
            </div>
        );
    }
}

export default FormHall;