
export default {
    namespace: "report",
    state: {
        data: []
    },
    effects: {
        
    },
    reducers: {
       
    }
};
