import React from "react";
import styles from "./index.less";

class ReportManagement extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <div>
                <h1 >报表管理</h1>
            </div>
        );
    }
}

export default ReportManagement;