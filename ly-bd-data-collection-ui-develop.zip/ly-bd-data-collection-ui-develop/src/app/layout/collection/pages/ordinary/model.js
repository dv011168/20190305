
export default {
    namespace: "ordinary",
    state: {
        data: []
    },
    effects: {
        
    },
    reducers: {
       
    }
};
