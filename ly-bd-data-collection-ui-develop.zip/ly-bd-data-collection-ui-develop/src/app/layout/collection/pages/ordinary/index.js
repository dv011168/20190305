import React from "react";
import { Card, Row, Col, Carousel } from "antd";
import {
    TagStatus,
    CarouselDot,
    CarouselArrow,
    LyCard,
    LyMore
} from "components";
import Bar from "./bar.js";
import styles from "./index.less";

export default class Ordinary extends React.Component {
    render() {
        const colSpan = {
            xs: 24,
            sm: 24,
            lg: 12,
            xl: 8,
            xxl: 6
        };
        return (
            <div>
                普通采集
                <div style={{ width: 300 }}>
                    <LyCard
                        height={430}
                        title="常用填写"
                        extra={<LyMore to={"/index"} />}
                    >
                        <CarouselDot
                            data={[
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                },
                                {
                                    img: require("images/personal/examined2.png"),
                                    name: "工作周报表"
                                }
                            ]}
                        />
                    </LyCard>
                </div>
                <div style={{ width: 500, background: "#fff" }}>
                    <CarouselArrow
                        data={[
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            },
                            {
                                img: require("images/personal/wdbb/rdb.png"),
                                name: "工作周报表"
                            }
                        ]}
                    />
                </div>
                <TagStatus status={2} />
                <Row gutter={20}>
                    {[0, 1, 2, 3, , 4, 5, 6].map((item, i) => {
                        return (
                            <Col key={i} {...colSpan}>
                                <Card
                                    title="Card title"
                                    bordered={false}
                                    style={{ marginBottom: 20 }}
                                >
                                    Card content
                                </Card>
                            </Col>
                        );
                    })}
                </Row>
                <Bar />
            </div>
        );
    }
}
