import React from "react";
import { Redirect, Switch } from "react-router-dom";
import { Layout, Icon, Menu } from "antd";
import { Scrollbars } from "components";
import { getCollectionMenu } from "app/route/menu.js";
import SidebarTwo from "app/route/sidebarTwo.js";
import AppRoute from "app/route/route";
/*工具类*/
import { getSize } from "utils/util";

const { Header, Sider, Content } = Layout;

class CollectionManagement extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            clientHeight: getSize().windowH // 屏幕高度
        };
    }
    componentDidMount() {
        window.addEventListener("resize", this.resize, false);
    }

    componentWillUnmount() {
        window.removeEventListener("resize", this.resize);
    }

    // 重置高度
    resize = () => {
        this.setState({
            clientHeight: getSize().windowH
        });
    };

    render() {
        const { clientHeight } = this.state;
        const { location } = this.props;
		const menuData = getCollectionMenu();
		
        return (
            <Layout style={{ height: clientHeight - 60 - 60 }}>
                {/* 左侧菜单栏 */}
                <Sider trigger={null} width={200} className="sider_menu">
                    <Scrollbars
                        style={{
                            height: "100%"
                        }}
                    >
                        <SidebarTwo collapsed={false} menuData={menuData} />
                    </Scrollbars>
                </Sider>
                <Layout
                    style={{
                        height: "100%"
                    }}
                >
                    <Switch
                        location={location}
                        key={location.pathname.split("/")[1]}
                    >
                        <AppRoute location={location} menuData={menuData} />
                    </Switch>
                </Layout>
            </Layout>
        );
    }
}

export default CollectionManagement;
