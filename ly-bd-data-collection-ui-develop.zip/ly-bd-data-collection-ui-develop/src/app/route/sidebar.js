import React from "react";
import { Icon, Menu } from "antd";
import { Link } from "react-router-dom";

const SubMenu = Menu.SubMenu;

export default class SideBar extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            collapsed: false
        };
    }

    render() {
        // props传递参数控制开关
        let { collapsed } = this.state;
        const { newCollapsed, menuData = [] } = this.props;
        if (newCollapsed != undefined) {
            collapsed = newCollapsed;
        }
        const reg = /^\/[\W\w]+[^?]/g;
        let menuItemUrl = location.hash.split("#")[1].match(reg);
		let selectUrl = "/" + menuItemUrl[0].split("/")[1];

        let subMenuUrl = menuItemUrl[0].split("/");
        subMenuUrl.pop();
        subMenuUrl.shift();
        subMenuUrl = subMenuUrl.map(item => {
            return "/" + item;
        });
        let arr = [];
        for (var i = 0; i < subMenuUrl.length; i++) {
            let str = "";
            for (var j = 0; j < i + 1; j++) {
                str += subMenuUrl[j];
            }
            arr.push(str);
        }

        const getMenu = item => {
			if(item.hide) return;
            if (item.children && item.children != "" && !item.hidechild) {
                let htmlct = [];
                let menuItem = item.children.map((item, i) => {
                    return getMenu(item);
                });
                htmlct.push(
                    <SubMenu
                        key={item.key}
                        title={
                            <span>
                               {item.icon && <Icon type={item.icon} />}
                                <span>{item.name}</span>
                            </span>
                        }
                    >
                        {menuItem}
                    </SubMenu>
                );
                return htmlct;
            } else {
                return (
                    <Menu.Item key={item.key}>
                        <Link to={item.path}>
                            {item.icon ? <Icon type={item.icon} /> : ""}
                            <span>{item.name}</span>
                        </Link>
                    </Menu.Item>
                );
            }
        };
        return (
            <Menu
                theme="light"
                mode="horizontal"
                defaultSelectedKeys={[selectUrl]}
                defaultOpenKeys={arr}
                inlineCollapsed={collapsed}
            >
                {menuData.map((item, index) => getMenu(item, index))}
            </Menu>
        );
    }
}
