import React from "react";
import { Route, Switch, Redirect } from "react-router-dom";

export default class AppRoute extends React.Component {
    constructor() {
        super();
        this.state = {};
    }

    render() {
        const location = this.props.location;
        // 菜单
        const { menuData = [], defaultUrl } = this.props;

        // 遍历菜单生成路由
        const getRouter = arr => {
            let routeList = [];
            for (let index = 0; index < arr.length; index++) {
                const item = arr[index];
                if (item.children && item.children != "") {
                    routeList = routeList.concat(getRouter(item.children));
                }
                if (item.component) {
                    routeList.push(
                        <Route
                            key={item.key}
                            location={location}
                            exact={item.exact === false ? false : true}
                            path={item.path}
                            component={item.component}
                        />
                    );
                }
            }
            return routeList;
        };

        return (
            <Switch location={location} key={location.pathname.split("/")[1]}>
                {getRouter(menuData)}
				{/* 路径匹配错误时跳转地址 */}
                {defaultUrl && <Route path="*" render={() => <Redirect to={defaultUrl} />} />}
            </Switch>
        );
    }
}
