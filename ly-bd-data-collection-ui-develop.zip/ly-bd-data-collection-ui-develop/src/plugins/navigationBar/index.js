import React from "react";
import { Breadcrumb } from "antd";
// import {
//     getMenuUrl,
// } from "app/route/menu";

import "./index.less";

class NavigationBar extends React.Component {
    constructor() {
        super();
        this.state = {};
    }
    render() {
        // const mainMenu = getMenuData();
        // const mainHideMenu = getHideMenu();
        // // 采集管理
        // const collectionMenu = getCollectionMenu();


        // // 真实地址
        // const curUrl = window.location.href.split("#")[1];
        // let breadcrumbList = [];

        // if (curUrl.indexOf("/collection") >= 0) {
        //     breadcrumbList.push({
        //         path: "/collection",
        //         name: "采集管理"
        //     });
        //     // 采集管理菜单
        //     for (let i = 0; i < collectionMenu.length; i++) {
        //         const item = collectionMenu[i];
        //         if (curUrl.indexOf(item.path) >= 0) {
        //             breadcrumbList.push({
        //                 path: item.path,
        //                 name: item.name
        //             });
        //             if (item.children) {
        //                 for (let j = 0; j < item.children.length; j++) {
        //                     if (curUrl.indexOf(item.children[j].path) >= 0) {
        //                         breadcrumbList.push({
        //                             path: item.children[j].path,
        //                             name: item.children[j].name
        //                         });
        //                     }
        //                 }
        //             }
        //         }
        //     }
        // } else {
        //     // 主菜单
        //     for (let i = 0; i < mainMenu.length; i++) {
        //         const item = mainMenu[i];
        //         if (curUrl.indexOf(item.path) >= 0) {
        //             breadcrumbList.push({
        //                 path: item.path,
        //                 name: item.name
        //             });
        //         }
        //     }
        //     // 隐藏菜单
        //     for (let i = 0; i < mainHideMenu.length; i++) {
        //         const item = mainHideMenu[i];
        //         if (curUrl.indexOf(item.path) >= 0) {
        //             breadcrumbList.push({
        //                 path: item.path,
        //                 name: item.name
        //             });
        //         }
        //     }
        // }
return null;
        return (
            <div id="Breadcrumb">
                <Breadcrumb>
                    {breadcrumbList.map((item, index) => {
                        if (index > 0 && index == breadcrumbList.length - 1) {
                            return (
                                <Breadcrumb.Item key={item.path}>
                                    <a href={item.path}>{item.name}</a>
                                </Breadcrumb.Item>
                            );
                        } else {
                            return (
                                <Breadcrumb.Item key={item.path}>
                                    {item.name}
                                </Breadcrumb.Item>
                            );
                        }
                    })}
                </Breadcrumb>
            </div>
        );
    }
}
export default NavigationBar;
