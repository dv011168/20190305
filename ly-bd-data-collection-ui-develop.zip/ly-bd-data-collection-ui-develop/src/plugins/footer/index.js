import React from "react";
import { config } from "../../app/config/global";
import './index.less';

export default class Footer extends React.Component {
    constructor() {
        super();
    }
    render() {
        return <div className="page_footer">{config.copyright}</div>;
    }
}
