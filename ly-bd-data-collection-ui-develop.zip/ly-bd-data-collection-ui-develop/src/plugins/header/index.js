import React from "react";
import { connect } from "react-redux";
import classNames from "classnames";
import { Menu, Divider, Icon, Avatar, Dropdown } from "antd";
import Sidebar from "../../app/route/sidebar";
import NoticeIcon from "../../plugins/noticeIcon";

import logoIcon from "images/logo.png";
import user from "images/user.png";
import news from "images/news.png";
import userChange from "images/userChange.png";

import "./index.less";

@connect(state => {
    let { login } = state;
    return { login };
})
export default class Top extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    // 登录
    handleClick = e => {
        if (e.key == "logout") {
            this.props.dispatch({
                type: "login/fetchLoginOut"
            });
        }
    };

    // 切换角色
    handleUserChange = e => {
        this.props.dispatch({
            type: "login/fetchUserTypeChange",
            userType: e.key
        });
    };

    render() {
        const { menuData, location, login = {} } = this.props;
		const { userInfo } = login;

        const menu = (
            <Menu className="menu" selectedKeys={[]} onClick={this.handleClick}>
                <Menu.Item key="logout">
                    <Icon type="logout" />
                    退出登录
                </Menu.Item>
            </Menu>
        );

        // 角色菜单
        const userMenu = (
            <Menu
                className="menu"
                selectedKeys={[userInfo.type]}
                onClick={this.handleUserChange}
            >
                <Menu.Item key="teacher">普通教师</Menu.Item>
                <Menu.Item key="admin">部门管理员</Menu.Item>
            </Menu>
        );

        // 头部菜单透明且定位的页面
        // const headList = ["/index"];
        // const pathname = location.pathname;

        return (
            <div
                className={classNames("page_header_box", {
                    // "page_header_box_absolute": headList.indexOf(pathname) >= 0
                })}
            >
                <div className="page_header_logo">
                    <img src={logoIcon} />
                </div>
                <div className="page_header_user">
                    <NoticeIcon />
                    <Dropdown overlay={menu}>
                        <span className="account">
                            <Avatar
                                size="small"
                                className="avatar"
                                src={user}
                            />
                            <span className="name">{userInfo.userName}</span>
                        </span>
                    </Dropdown>
                    <Dropdown overlay={userMenu}>
                        <span className="userType">
                            <img src={userChange} />
                            <span className="name">{userInfo.typeName}</span>
                        </span>
                    </Dropdown>
                </div>
                <div className="page_header">
                    <Sidebar menuData={menuData} />
                </div>
            </div>
        );
    }
}
