import React from "react";
import { connect } from "react-redux";
import { Route, Router, Link, Redirect, Switch } from "react-router-dom";
import { Layout, Icon, Menu } from "antd";
import createHistory from "history/createHashHistory";
// import CSSTransitionGroup from 'react-transition-group/CSSTransitionGroup'
import { Scrollbars } from "components";
import asyncComponent from "utils/asyncComponent"; //按需加载组件
import { getMenuData } from "../../app/route/menu.js";
/*工具类*/
import { getSize } from "../../utils/util";

/*数据*/
import AppRoute from "app/route/route"; // 菜单路由

/*公用组件*/
import Footer from "../footer/index";
import Top from "../header/index";

/********************公共页面-开始***************************/
const commonRoute = [
    {
        path: "/login", // 登录页面
        exact: true,
        component: asyncComponent({
            loader: () => import("src/plugins/login")
        })
    }
];
/********************公共页面-结束***************************/

const { Header, Sider, Content } = Layout;
var history = createHistory();

const NotMatch = ({ location }) => (
    <div>
        <h3>No Match for {location.pathName}</h3>
    </div>
);

@connect(state => {
    const { login } = state;
    return { login };
})
export default class Container extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            collapsed: false, //侧边栏开关
            clientHeight: getSize().windowH // 屏幕高度
        };
    }

    componentDidMount() {
        window.addEventListener("resize", this.resize, false);
    }

    componentWillUnmount() {
        window.removeEventListener("resize", this.resize);
    }

    // 重置高度
    resize = () => {
        this.setState({
            clientHeight: getSize().windowH
        });
    };

    //菜单收缩
    toggle = () => {
        this.setState({
            collapsed: !this.state.collapsed
        });
    };

    // 权限过滤
    getMenuList = (allMenu, authority) => {
        const menu = [...allMenu];
        let menuList = [];
        for (let index = 0; index < menu.length; index++) {
            const item = menu[index];
            let newItem = undefined;
            if (item.authority) {
                if (item.authority.includes(authority)) {
                    newItem = { ...item };
                }
            } else {
                newItem = { ...item };
            }
            if (item.children && newItem) {
                newItem.children = this.getMenuList(item.children, authority);
            }
            if (newItem) {
                menuList.push(newItem);
            }
        }
        return menuList;
    };

    render() {
        const { collapsed, clientHeight } = this.state;
        const { login } = this.props;
        const menuData = this.getMenuList(getMenuData(), login.userInfo.type);

        return (
            <Router history={history}>
                <Route
                    render={({ location }) => {
                        return (
                            <div
                                style={{
                                    minWidth: "1180px"
                                }}
                            >
                                <Switch location={location}>
                                    <Route
                                        location={location}
                                        exact
                                        path="/"
                                        render={() => <Redirect to="index" />}
                                    />
                                    {/* 公共路由 */}
                                    {commonRoute.map(item => {
                                        const {
                                            path,
                                            component,
                                            ...other
                                        } = item;
                                        return (
                                            <Route
                                                location={location}
                                                path={path}
                                                key={path}
                                                component={component}
                                                {...other}
                                            />
                                        );
                                    })}
                                    {/* 页面路由 */}
                                    <Route
                                        location={location}
                                        render={({ location }) => {
                                            return (
                                                <Layout>
                                                    {/* 头部公用组件 */}
                                                    <Top
                                                        collapsed={collapsed}
                                                        toggle={this.toggle}
                                                        menuData={menuData}
                                                        location={location}
                                                    />
                                                    <Content
                                                        style={{
                                                            minHeight:
                                                                clientHeight -
                                                                60 -
                                                                60
                                                        }}
                                                    >
                                                        {/* 路由设置 页面显示区域 */}
                                                        <Switch
                                                            location={location}
                                                            key={
                                                                location.pathname.split(
                                                                    "/"
                                                                )[1]
                                                            }
                                                        >
                                                            <AppRoute
                                                                location={
                                                                    location
                                                                }
                                                                menuData={
                                                                    menuData
                                                                }
																defaultUrl="index"
                                                            />
                                                        </Switch>
                                                    </Content>
                                                    <Footer />
                                                </Layout>
                                            );
                                        }}
                                    />
                                </Switch>
                            </div>
                        );
                    }}
                />
            </Router>
        );
    }
}
