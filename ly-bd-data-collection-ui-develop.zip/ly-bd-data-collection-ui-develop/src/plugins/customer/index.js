import React from "react";
import phoneIcon from "images/phone.png";
import zaixianzixunIcon from "images/zaixianzixun.png";

import "./index.less";

export default class Customer extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="page_customer">
                <div className="page_customer_item">
                    <img src={phoneIcon} />
                    <div>电话咨询</div>
                </div>
                <div className="page_customer_item">
                    <img src={zaixianzixunIcon} />
                    <div>在线咨询</div>
                </div>
            </div>
        );
    }
}
