import React from "react";
import { config } from "../../app/config/global";
import "./index.less";

export default class Footer extends React.Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div className="page_footer_info">
                <div className="w1180 page_footer_con">
                    <img
                        className="page_footer_con_icon"
                        src={require("images/logo.png")}
                    />
                    <div className="page_footer_info_item">
                        <div className="page_footer_info_left">
                            <a className="left_item">在线咨询</a>
                            <span className="left_item">在线帮助：</span>
                        </div>
                        <div className="page_footer_info_right">
                            <a>在线知识库</a>
                            <a>一表通在线帮助手册</a>
                            <a>高基表在线帮助手册</a>
                        </div>
                    </div>
                    <div className="page_footer_info_item">
                        <div className="page_footer_info_left">
                            <a className="left_item">意见反馈</a>
                            <span className="left_item">快速入口：</span>
                        </div>
                        <div className="page_footer_info_right">
                            <a>信息标准管理系统</a>
                            <a>主数据管理系统</a>
                            <a>数据质量管理系统</a>
                            <a>接口管理系统</a>
                            <a>元数据管理系统</a>
                            <a>数据资产信息服务系统</a>
                            <a>数据反馈系统</a>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
