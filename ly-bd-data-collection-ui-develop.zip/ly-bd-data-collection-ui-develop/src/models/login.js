import { reqPostLogin } from "utils/api";
import createHistory from "history/createHashHistory";
import { Modal } from "antd";

var history = createHistory();

// 用户数据
const userList = [
    {
        type: "teacher",
        typeName: "普通教师",
        userName: "普通教师"
    },
    {
        type: "admin",
        typeName: "管理员",
        userName: "管理员"
    }
];

const initState = sessionStorage.getItem("userLogin")
    ? { data: JSON.parse(sessionStorage.getItem("userLogin")) }
    : {
          data: {}
      };

export default {
    namespace: "login",
    state: {
        ...initState,
        userInfo: userList[0]
    },
    effects: {
        *fetchLogin({ payload: formData }, { put, call, select }) {
            // 发起登录请求
            const res = yield call(reqPostLogin, formData);
            if (res.state != false) {
                yield put({
                    type: "setData",
                    payload: {
                        ...formData,
                        data: res
                    }
                });
                sessionStorage.setItem("userLogin", JSON.stringify(res));
                // 跳转首页
                history.push("/index");
            } else {
                Modal.error({
                    title: "登录失败",
                    content: "账号或者密码有误！"
                });
                yield put({
                    type: "clearData"
                });
            }
        },
        *fetchLoginOut({}, { put, call, select }) {
            // 清除缓存
            sessionStorage.clear();
            yield put({
                type: "clearData"
            });
            // 跳转登录页
            history.push("/login");
            // Modal.error({ title: "登出失败", content: res.message });
        },
        // 切换用户类型
        *fetchUserTypeChange({ userType }, { put, call, select }) {
			const userInfoList = userList.filter(item => item.type == userType);
            yield put({
                type: "setData",
                payload: {
                    userInfo: userInfoList[0]
                }
            });
        }
    },
    reducers: {
        setData(state, { payload: payload }) {
            return { ...state, ...payload };
        },
        clearData(state, {}) {
            return { data: {} };
        }
    }
};
